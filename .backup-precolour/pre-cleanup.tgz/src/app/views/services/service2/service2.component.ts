import { Component } from '@angular/core';
import { BreadcrumbComponent } from '../../../components/breadcrumb.component';
import { RouterLink } from '@angular/router';
import { ThemePaginationComponent } from "../../../components/theme-pagination.component";
import { BodyClassDirective } from "../../../directive/body-class.directive";

type blogType = {
  image: string;
  title: string;
  des: string;
};

@Component({
  selector: 'app-service2',
  imports: [BreadcrumbComponent, RouterLink, ThemePaginationComponent, BodyClassDirective],
  templateUrl: './service2.component.html',
  styles: ``,
})
export class Service2Component {


  blogData: blogType[] = [
    {
      image: 'assets/img/image/blog1-img1.png',
      title: 'HR Strategy and Planning',
      des: 'Our expert consultants work with you to develop a comprehensive HR strategy aligned with your business goals. We assess your current HR',
    },
    {
      image: 'assets/img/image/blog1-img2.png',
      title: 'HR Compliance and Policies',
      des: 'Our expert consultants work with you to develop a comprehensive HR strategy aligned with your business goals. We assess your current HR',
    },
    {
      image: 'assets/img/image/blog1-img3.png',
      title: 'HR Technology Solutions',
      des: 'Our expert consultants work with you to develop a comprehensive HR strategy aligned with your business goals. We assess your current HR',
    },
    {
      image: 'assets/img/image/blog1-img4.png',
      title: 'Organizational Change Management',
      des: 'Our expert consultants work with you to develop a comprehensive HR strategy aligned with your business goals. We assess your current HR ',
    },
    {
      image: 'assets/img/image/blog1-img5.png',
      title: 'HR Strategy and Planning',
      des: 'Our expert consultants work with you to develop a comprehensive HR strategy aligned with your business goals. We assess your current HR',
    },
    {
      image: 'assets/img/image/blog1-img6.png',
      title: 'HR Strategy and Planning',
      des: 'Our expert consultants work with you to develop a comprehensive HR strategy aligned with your business goals. We assess your current HR',
    },
    {
      image: 'assets/img/image/blog1-img7.png',
      title: 'Organizational Change Management',
      des: 'Our expert consultants work with you to develop a comprehensive HR strategy aligned with your business goals. We assess your current HR',
    },
    {
      image: 'assets/img/image/blog1-img8.png',
      title: 'HR Technology Solutions',
      des: 'Our expert consultants work with you to develop a comprehensive HR strategy aligned with your business goals. We assess your current HR',
    },
    {
      image: 'assets/img/image/blog1-img9.png',
      title: 'Organizational Change Management',
      des: 'Our expert consultants work with you to develop a comprehensive HR strategy aligned with your business goals. We assess your current HR',
    },
  ];
}
