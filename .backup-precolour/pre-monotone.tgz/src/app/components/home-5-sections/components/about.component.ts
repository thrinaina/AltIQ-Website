import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CountUpModule } from 'ngx-countup';

@Component({
  selector: 'app-about',
  host: { 'app-about': 'app-single-about5' },
  imports: [RouterLink,CountUpModule],
  template: `
    <div class="about5 sp3" id="about" style="background-color: #F1F1F5;">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6">
            <div class="about5-images">
              <div class="aobut5-img1">
                <img src="assets/img/shapes/about5-shape.svg" alt="" />
              </div>
              <div class="aobut5-img2 img5 img100">
                <img src="assets/img/image/about5-img.png" alt="" />
              </div>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="hadding5">
              <h1 data-aos="fade-left" data-aos-duration="700">
                Best Financial Company for Your Business
              </h1>
              <div class="space16"></div>
              <p data-aos="fade-left" data-aos-duration="900">
                At Advisor Consulting, we are a trusted finance consulting firm
                dedicated to helping businesses achieve financial excellence and
                sustainable growth. The to Whether your dream is to retire well
                or build a profitable business' JS Morlu offer a diverse range
                of exclusive accounting, tax, on audit and business.
              </p>
              <div class="row">
                <div class="col-md-6">
                  <div
                    class="about5-counter-box"
                    data-aos="fade-left"
                    data-aos-duration="700"
                  >
                    <h1><span class="counter" [countUp]="76" [options]="{ suffix : '+'}"></span></h1>
                    <p>Projects Completed</p>
                  </div>
                </div>
                <div
                  class="col-md-6"
                  data-aos="fade-left"
                  data-aos-duration="1000"
                >
                  <div class="about5-counter-box">
                    <h1><span class="counter" [countUp]="76" [options]="{ suffix : '+'}" ></span></h1>
                    <p>Projects Completed</p>
                  </div>
                </div>
              </div>

              <div class="space40"></div>

              <div class="" data-aos="fade-left" data-aos-duration="1000">
                <a routerLink="/contact" class="theme-btn5"
                  >Plan Your Financial Future<span
                    ><i class="fa-solid fa-angle-right"></i></span
                ></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: ``,
})
export class AboutComponent {}
