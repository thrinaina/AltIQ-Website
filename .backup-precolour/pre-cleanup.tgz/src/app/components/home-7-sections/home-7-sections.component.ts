import { Component } from '@angular/core';
import { HeroComponent } from './components/hero.component';
import { ServicesComponent } from './components/services.component';
import { AboutComponent } from './components/about.component';
import { TeamComponent } from './components/team.component';
import { TestimonialComponent } from './components/testimonial.component';
import { CounterComponent } from './components/counter.component';
import { BlogComponent } from './components/blog.component';
import { ContactComponent } from './components/contact.component';
import { CtaComponent } from './components/cta.component';
import { FooterComponent } from './components/footer.component';

@Component({
  selector: 'app-home-7-sections',
  imports: [HeroComponent,ServicesComponent,AboutComponent,TeamComponent,TestimonialComponent,CounterComponent,BlogComponent,ContactComponent,CtaComponent,FooterComponent],
  templateUrl: './home-7-sections.component.html',
  styles: ``
})
export class Home7SectionsComponent {

}
