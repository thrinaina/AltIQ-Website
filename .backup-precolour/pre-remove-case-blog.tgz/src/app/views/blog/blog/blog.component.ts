import { Component } from '@angular/core';
import { BreadcrumbComponent } from '../../../components/breadcrumb.component';
import { RouterLink } from '@angular/router';
import { ThemePaginationComponent } from "../../../components/theme-pagination.component";
import { BodyClassDirective } from "../../../directive/body-class.directive";

type BlogType = {
  image: string;
  date: string;
  des: string;
};

@Component({
  selector: 'app-blog',
  imports: [BreadcrumbComponent, RouterLink, ThemePaginationComponent, BodyClassDirective],
  templateUrl: './blog.component.html',
  styles: ``,
})
export class BlogComponent {
 

  blogData: BlogType[] = [
    {
      image: 'assets/img/image/blog1-img1.png',
      date: '11 March, 2023',
      des: 'How consultation in business is affecting new ventures',
    },
    {
      image: 'assets/img/image/blog1-img2.png',
      date: '16 March, 2023',
      des: 'Challanges of consultating new Business Firms',
    },
    {
      image: 'assets/img/image/blog1-img3.png',
      date: '03 April, 2023',
      des: 'Revitalising your people in to a retail downturn',
    },
    {
      image: 'assets/img/image/blog1-img4.png',
      date: '15 March, 2023',
      des: 'Customized Solutions: Based on our analysis, we develop',
    },
    {
      image: 'assets/img/image/blog1-img5.png',
      date: '22 April, 2023',
      des: 'Explore our regularly updated blog, where we share expert',
    },
    {
      image: 'assets/img/image/blog1-img6.png',
      date: '19 March, 2023',
      des: `Our commitment doesn't end with implementation.`,
    },
    {
      image: 'assets/img/image/blog1-img7.png',
      date: '15 March, 2023',
      des: 'Customized Solutions: Based on our analysis, we develop',
    },
    {
      image: 'assets/img/image/blog1-img8.png',
      date: '22 April, 2023',
      des: 'Explore our regularly updated blog, where we share expert',
    },
    {
      image: 'assets/img/image/blog1-img9.png',
      date: '22 April, 2023',
      des: 'Explore our regularly updated blog, where we share expert',
    },
  ];

}
