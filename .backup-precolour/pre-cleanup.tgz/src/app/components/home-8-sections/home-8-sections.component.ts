import { Component } from '@angular/core';
import { HeroComponent } from './components/hero.component';
import { AboutComponent } from './components/about.component';
import { ServicesComponent } from './components/services.component';
import { ProgressComponent } from './components/progress.component';
import { IndustriesComponent } from './components/industries.component';
import { TestimonialComponent } from './components/testimonial.component';
import { BlogComponent } from './components/blog.component';
import { CtaComponent } from './components/cta.component';
import { FooterComponent } from './components/footer.component';

@Component({
  selector: 'app-home-8-sections',
  imports: [HeroComponent,AboutComponent,ServicesComponent,ProgressComponent,IndustriesComponent,TestimonialComponent,BlogComponent,CtaComponent,FooterComponent],
  templateUrl: './home-8-sections.component.html',
  styles: ``
})
export class Home8SectionsComponent {

}
