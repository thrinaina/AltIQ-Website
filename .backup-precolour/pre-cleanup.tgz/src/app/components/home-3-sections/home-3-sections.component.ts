import { Component } from '@angular/core';
import { HeroComponent } from "./components/hero.component";
import { ServicesComponent } from "./components/services.component";
import { AboutComponent } from "./components/about.component";
import { MissionComponent } from "./components/mission.component";
import { FeaturesComponent } from "./components/features.component";
import { TestimonialComponent } from "./components/testimonial.component";
import { BlogComponent } from "./components/blog.component";
import { ContactComponent } from "./components/contact.component";
import { FooterComponent } from "./components/footer.component";

@Component({
  selector: 'app-home-3-sections',
  imports: [HeroComponent, ServicesComponent, AboutComponent, MissionComponent, FeaturesComponent, TestimonialComponent, BlogComponent, ContactComponent, FooterComponent],
  templateUrl: './home-3-sections.component.html',
  styles: ``
})
export class Home3SectionsComponent {

}
