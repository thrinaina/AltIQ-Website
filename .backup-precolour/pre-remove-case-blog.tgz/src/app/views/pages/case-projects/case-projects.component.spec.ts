import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseProjectsComponent } from './case-projects.component';

describe('CaseProjectsComponent', () => {
  let component: CaseProjectsComponent;
  let fixture: ComponentFixture<CaseProjectsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CaseProjectsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CaseProjectsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
