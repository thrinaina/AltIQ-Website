import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CountUpModule } from 'ngx-countup';

@Component({
  selector: 'app-about',
  host: { 'app-about': 'app-about2' },
  imports: [CountUpModule,RouterLink],
  template: `
     <div class="about1 sp3" id="about" style="background-color: var(--aiq-surface-2);">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-lg-6">
              <div class="about1-image-all">
                <div class="about-1-img1 aniamtion-key-1">
                  <img src="assets/img/shapes/about1-shape1.svg" alt="">
                </div>
                <div class="about-1-img2 border5" data-aos="fade-down" data-aos-duration="700">
                  <img src="assets/img/image/about1-img1.png" alt="">
                </div>
                <div class="about-1-img3 border5" data-aos="fade-left" data-aos-duration="700">
                  <img src="assets/img/image/about1-img2.png" alt="">
                </div>
                <div class="about-1-img4"  data-aos="fade-up" data-aos-duration="700">
                  <div class="about-counter-box">
                    <div class="about-counter-text">
                      <h1 [countUp]="16"></h1>
                      <p>Years <br> Experience</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="hadding1 about1-hadding">
                <h1 class="titleGreathorned" data-aos="fade-left" data-aos-duration="700">Partner with Our Trusted Consultants Today.</h1>
                <div class="space24"></div>
                <p data-aos="fade-left" data-aos-duration="900">At Advisor Consulting Company, we are a trusted business consulting firm dedicated to helping businesses thrive and reach their full potential.Our team of experienced consultants brings diverse industry </p>
                <div class="space20"></div>
                <p data-aos="fade-left" data-aos-duration="700">knowledge and expertise in various business disciplines.We prioritize understanding your unique challenges and goals to deliver customized solutions tailored to your specific needs</p>
                <div class="space40"></div>
                <a routerLink="/service" data-aos="fade-left" data-aos-duration="900" class="btn_theme btn_theme btn_theme_active wow fadeInDown1" data-wow-duration="0.8s">More About Us<span></span></a>
              </div>
            </div>
          </div>
        </div>
      </div>
  `,
  styles: ``
})
export class AboutComponent {

}
