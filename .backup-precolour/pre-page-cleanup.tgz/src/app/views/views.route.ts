import { Route } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { ServiceComponent } from './services/service/service.component';
import { Service2Component } from './services/service2/service2.component';
import { ServiceDetailsComponent } from './services/service-details/service-details.component';
import { CaseComponent } from './pages/case/case.component';
import { CaseDetails1Component } from './pages/case-details1/case-details1.component';
import { CaseDetails2Component } from './pages/case-details2/case-details2.component';
import { FaqComponent } from './pages/faq/faq.component';
import { ErrorComponent } from './pages/error/error.component';
import { BlogComponent } from './blog/blog/blog.component';
import { Blog2Component } from './blog/blog2/blog2.component';
import { BlogSidebarLeftComponent } from './blog/blog-sidebar-left/blog-sidebar-left.component';
import { BlogSidebarRightComponent } from './blog/blog-sidebar-right/blog-sidebar-right.component';
import { BlogDetailsSidebarLeftComponent } from './blog/blog-details-sidebar-left/blog-details-sidebar-left.component';
import { BlogDetailsSidebarRightComponent } from './blog/blog-details-sidebar-right/blog-details-sidebar-right.component';
import { BlogDetailsComponent } from './blog/blog-details/blog-details.component';
import { ContactComponent } from './contact/contact.component';

const T = ' || AltIQ Labs';

export const VIEWS_ROUTE: Route[] = [
  { path: 'about',        component: AboutComponent,        data: { title: 'About' + T } },
  { path: 'service',      component: ServiceComponent,      data: { title: 'Service Catalog' + T } },
  { path: 'service2',     component: Service2Component,     data: { title: 'Service Catalog' + T } },
  { path: 'service-details', component: ServiceDetailsComponent, data: { title: 'Service' + T } },
  { path: 'case',         component: CaseComponent,         data: { title: 'Case Studies' + T } },
  { path: 'case-details1', component: CaseDetails1Component, data: { title: 'Case Study' + T } },
  { path: 'case-details2', component: CaseDetails2Component, data: { title: 'Case Study' + T } },
  { path: 'faq',          component: FaqComponent,          data: { title: 'FAQ' + T } },
  { path: 'blog',         component: BlogComponent,         data: { title: 'Insights' + T } },
  { path: 'blog2',        component: Blog2Component,        data: { title: 'Insights' + T } },
  { path: 'blog-sidebar-left',  component: BlogSidebarLeftComponent,  data: { title: 'Insights' + T } },
  { path: 'blog-sidebar-right', component: BlogSidebarRightComponent, data: { title: 'Insights' + T } },
  { path: 'blog-details', component: BlogDetailsComponent,  data: { title: 'Insight' + T } },
  { path: 'blog-details-sidebar-left',  component: BlogDetailsSidebarLeftComponent,  data: { title: 'Insight' + T } },
  { path: 'blog-details-sidebar-right', component: BlogDetailsSidebarRightComponent, data: { title: 'Insight' + T } },
  { path: 'contact',      component: ContactComponent,      data: { title: 'Contact Us' + T } },
  { path: '**',           component: ErrorComponent,        data: { title: 'Page Not Found' + T } },
];
