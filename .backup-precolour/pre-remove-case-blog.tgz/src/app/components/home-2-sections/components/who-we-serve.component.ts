import { Component } from '@angular/core';

@Component({
  selector: 'app-who-we-serve',
  template: `
    <div class="counter1" style="background-color: var(--aiq-950); padding: 80px 0">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 m-auto text-center">
            <div class="hadding1">
              <h1 class="font-w" data-aos="fade-up" data-aos-duration="700"
                  style="color: var(--aiq-white);">
                Who We Serve
              </h1>
              <div class="space24"></div>
              <p data-aos="fade-up" data-aos-duration="900" style="color: var(--aiq-200);">
                Mid-market enterprises lacking full technology leadership teams,
                undergoing digital transformation, or needing specialised talent
                without permanent overhead.
              </p>
            </div>
          </div>
        </div>
        <div class="space40"></div>
        <div class="row">
          @for (industry of industries; track $index) {
          <div class="col-lg col-md-4 col-6 text-center">
            <div data-aos="fade-up" [attr.data-aos-duration]="700 + $index * 100">
              <p style="color: var(--aiq-300); font-size: 20px; font-weight: 600;">
                {{ industry }}
              </p>
            </div>
          </div>
          }
        </div>
      </div>
      <div class="counter1-bg-img aniamtion-key-1">
        <img src="assets/img/shapes/counter-shape.svg" alt="" />
      </div>
    </div>
  `,
  styles: ``,
})
export class WhoWeServeComponent {
  industries: string[] = [
    'Manufacturing',
    'Healthcare',
    'Financial Services',
    'Retail',
    'Technology',
  ];
}
