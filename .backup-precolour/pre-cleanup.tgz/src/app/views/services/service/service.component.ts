import { Component } from '@angular/core';
import { BreadcrumbComponent } from '../../../components/breadcrumb.component';
import { RouterLink } from '@angular/router';
import { BodyClassDirective } from "../../../directive/body-class.directive";

type servicesType = {
  icon: string;
  name: string;
  des: string;
};

@Component({
  selector: 'app-service',
  imports: [BreadcrumbComponent, RouterLink, BodyClassDirective],
  templateUrl: './service.component.html',
  styles: ``,
})

export class ServiceComponent {


  servicesData:servicesType[] = [
    {
      icon: 'assets/img/icons/service1-icon1.svg',
      name: 'HR Strategy and Planning',
      des: 'Our expert consultants work with you to develop a comprehensive HR strategy aligned with your business goals. <br> We assess your current HR',
    },
    {
      icon: 'assets/img/icons/service1-icon2.svg',
      name: 'HR Compliance and Policies',
      des: 'We ensure your HR policies and procedures are compliant with local labor laws and regulations. Our consultants review and update your employee handbook',
    },
    {
      icon: 'assets/img/icons/service1-icon3.svg',
      name: 'HR Technology Solutions',
      des: 'We ensure your HR policies and procedures are compliant with local labor laws and regulations. Our consultants review and update your employee handbook',
    },
    {
      icon: 'assets/img/icons/service1-icon4.svg',
      name: 'Organizational Change Management',
      des: 'We ensure your HR policies and procedures are compliant with local labor laws and regulations. Our consultants review and update your employee handbook',
    },
    {
      icon: 'assets/img/icons/service1-icon5.svg',
      name: 'HR Strategy and Planning',
      des: 'Our expert consultants work with you to develop a comprehensive HR strategy aligned with your business goals. <br> We assess your current HR',
    },
    {
      icon: 'assets/img/icons/service1-icon6.svg',
      name: 'HR Compliance and Policies',
      des: 'We ensure your HR policies and procedures are compliant with local labor laws and regulations. Our consultants review and update your employee handbook',
    },
    {
      icon: 'assets/img/icons/service1-icon7.svg',
      name: 'HR Technology Solutions',
      des: 'We ensure your HR policies and procedures are compliant with local labor laws and regulations. Our consultants review and update your employee handbook',
    },
    {
      icon: 'assets/img/icons/service1-icon8.svg',
      name: 'Organizational Change Management',
      des: 'We ensure your HR policies and procedures are compliant with local labor laws and regulations. Our consultants review and update your employee handbook',
    },
  ];
}
