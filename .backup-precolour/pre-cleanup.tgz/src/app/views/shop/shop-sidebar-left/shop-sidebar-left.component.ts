import { Component } from '@angular/core';
import { BreadcrumbComponent } from '../../../components/breadcrumb.component';
import { ShopLeftComponent } from '../components/shop-left.component';
import { ShopRightComponent } from '../components/shop-right.component';
import { BodyClassDirective } from "../../../directive/body-class.directive";


@Component({
  selector: 'app-shop-sidebar-left',
  imports: [BreadcrumbComponent, ShopLeftComponent, ShopRightComponent, BodyClassDirective],
  templateUrl: './shop-sidebar-left.component.html',
  styles: ``,
})
export class ShopSidebarLeftComponent {

}
