import { Component } from '@angular/core';
import { BreadcrumbComponent } from "../../../components/breadcrumb.component";
import { CaseProjectsComponent } from "../case-projects/case-projects.component";
import { CaseLeftComponent } from '../components/case-left.component';
import { CaseRightComponent } from '../components/case-right.component';
import { BodyClassDirective } from "../../../directive/body-class.directive";

@Component({
  selector: 'app-case-details1',
  imports: [BreadcrumbComponent, CaseProjectsComponent, CaseLeftComponent, CaseRightComponent, BodyClassDirective],
  templateUrl: './case-details1.component.html',
  styles: ``,
})
export class CaseDetails1Component {

}
