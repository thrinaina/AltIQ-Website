import { Component } from '@angular/core';
import { BreadcrumbComponent } from "../../../components/breadcrumb.component";
import { RouterLink } from '@angular/router';
import { BodyClassDirective } from "../../../directive/body-class.directive";

@Component({
  selector: 'app-service-details',
  imports: [BreadcrumbComponent, RouterLink, BodyClassDirective],
  templateUrl: './service-details.component.html',
  styles: ``
})
export class ServiceDetailsComponent {

 
  serviceslist: string[] = [
    "HR Strategy and Planning",
    "HR Compliance and Policies",
    "HR Technology Solutions",
    "Organizational  Management",
    "Employee Engagement",
    "HR Technology Solutions"
  ]

}
