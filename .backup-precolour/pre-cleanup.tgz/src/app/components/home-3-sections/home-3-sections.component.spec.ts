import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home3SectionsComponent } from './home-3-sections.component';

describe('Home3SectionsComponent', () => {
  let component: Home3SectionsComponent;
  let fixture: ComponentFixture<Home3SectionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Home3SectionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Home3SectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
