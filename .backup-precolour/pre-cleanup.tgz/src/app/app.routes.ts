import { Routes } from '@angular/router';
import { LayoutComponent } from './layout/layout.component';

export const routes: Routes = [
     {
        path: '',
        redirectTo: 'multi/home-1',
        pathMatch: 'full',
    },
    {
        path: '',
        loadChildren: () => import('./multi-pages/multi-pages.route').then((mod) => mod.MULTI_PAGES_ROUTES)
    },
    {
        path: '',
        loadChildren: () => import('./single-pages/single-pages.route').then((mod) => mod.SINGLE_PAGES_ROUTES)
    },
    {
        path: '',
        component: LayoutComponent,
        loadChildren: () => import('./views/views.route').then((mod) => mod.VIEWS_ROUTE)
    },
];




