import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

type casestudyType = {
  image: string;
  title: string;
  link: string;
  aosDuration: string;
};

@Component({
  selector: 'app-case-study',
  host: { 'app-case-study': 'app-case-study5' },
  imports: [RouterLink],
  template: `
    <div class="case6 sp3" id="case">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 m-auto text-center">
            <div class="hadding6">
              <h1 data-aos="fade-up" data-aos-duration="800">
                Featured Case Studies
              </h1>
              <div class="space16"></div>
              <p data-aos="fade-up" data-aos-duration="1000">
                Consulting service is a key part of the future of energy. It can
                help you save electricity bill, and it can also help to reduce
                your carbon footprint.
              </p>
            </div>
          </div>
        </div>

        <div class="space30"></div>
        <div class="row">
          @for (case of caseStudies; track case) {
          <div class="col-lg-4 cal-md-6">
            <div
              class="case6-box"
              [attr.data-aos]="'fade-up'"
              [attr.data-aos-duration]="case.aosDuration"
            >
              <div class="case6-img-box img100 img5">
                <img [src]="case.image" alt="" />
              </div>
              <div class="case6-hadding-area">
                <h5>
                  <a [routerLink]="case.link">{{ case.title }}</a>
                </h5>
                <div class="space20"></div>
                <a [routerLink]="case.link" class="case6-learn">
                  Read More <span><i class="fa-solid fa-arrow-right"></i></span>
                </a>
              </div>
            </div>
          </div>
          }
        </div>

        <div class="space40"></div>
        <div class="row">
          <div class="col-lg-12 text-center">
            <div class="" data-aos="fade-up" data-aos-duration="1200">
              <a routerLink="/cart" class="theme-btn7">More Case Studies</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: ``,
})
export class CaseStudyComponent {

  caseStudies: casestudyType[] = [
    {
      image: 'assets/img/image/case6-img1.png',
      title: 'Managements Employee Handbook Development for Company Growth',
      link: '/case-details1',
      aosDuration: '800',
    },
    {
      image: 'assets/img/image/case6-img2.png',
      title: 'Business Strategic Employee Trust Handbook for Company Gro',
      link: '/case-details1',
      aosDuration: '1000',
    },
    {
      image: 'assets/img/image/case6-img3.png',
      title: 'Human Recourses Trusted By Our Customers to Effective Solution',
      link: '/case-details1',
      aosDuration: '1200',
    },
  ];
  
}
