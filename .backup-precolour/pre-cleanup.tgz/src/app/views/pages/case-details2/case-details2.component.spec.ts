import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseDetails2Component } from './case-details2.component';

describe('CaseDetails2Component', () => {
  let component: CaseDetails2Component;
  let fixture: ComponentFixture<CaseDetails2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CaseDetails2Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CaseDetails2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
