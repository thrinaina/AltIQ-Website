import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-cta',
  host: { 'app-cta': 'app-cta1' },
  imports: [RouterLink],
  template: `
     <div class="cta2" style="background-image: url(assets/img/bg/cta2-bg.png); background-position: center; background-repeat: no-repeat; background-size: cover; background-attachment: fixed; padding: 70px 0">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="hadding2-w">
                        <h1 data-aos="fade-up" data-aos-duration="700">Take <span class="after2">advantage</span> of a  consultation</h1>
                    </div>
                </div>
                <div class="col-lg-6 text-right">
                    <div class="header2-buttons header2-buttons2">
                        <div class="button2-all" data-aos-duration="800" data-aos="fade-up">
                            <a routerLink="/service-details" class="button-h-2 btnfos2">Schedule A Consultation</a>
                        </div>
                        <div class="button2-all2" data-aos-duration="800" data-aos="fade-down">
                            <a [routerLink]="[]" class="button-h2-2 btnfos4">Learn More</a>
                        </div>
                     </div>
                </div>
            </div>
        </div>
      </div>
  `,
  styles: ``
})
export class CtaComponent {

}
