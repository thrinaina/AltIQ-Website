import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-cta',
  host: { 'app-cta': 'app-cta4' },
  imports: [RouterLink],
  template: `
       <div class="subscribe4" style="background-image: url(assets/img/bg/subscribe4-bg.png); padding: 80px 0; background-attachment: fixed; background-position: center; background-size: cover; background-repeat: no-repeat;">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 m-auto text-center">
                    <div class="hadding4-w">
                        <h1 data-aos="fade-up" data-aos-duration="700">Take advantage of a  consultation</h1>
                        <div class="space16"></div>
                        <p data-aos="fade-up" data-aos-duration="800">Take advantage of a one on one consultation with our tax experts. We'll assess your unique situation and provide personalized advice and strategies.</p>
                        <div class="space40"></div>
                        <div class="header3-buttons header4-button-subsribe">
                          <div class="header4-button">
                            <a routerLink="/contact" class="button4-header">Schedule A Consultation</a>
                            <a routerLink="/about" class="header4-button4">Learn More</a>
                          </div>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  `,
  styles: ``
})
export class CtaComponent {

}
