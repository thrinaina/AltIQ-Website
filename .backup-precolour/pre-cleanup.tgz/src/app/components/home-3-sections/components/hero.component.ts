import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-hero',
  host: { 'app-hero': 'app-hero3' },
  imports: [RouterLink],
  template: `

     <div class="main-hero main-hero3">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-lg-6 col-md-12">
              <div class="main-hadding3">
                <h1>Expert Tax Consulting Services for Individual and Businesses.</h1>
                <div class="space24"></div>
                <p>Maximize Your Tax Saving and Ensure Compliance.We help businesses to perform with our customized solutions helping them take business decisions.</p>
                <div class="space40"></div>
                <div class="header3-buttons">
                        <div class="">
                            <a class="buttonBox2 fifth" routerLink="/contact">Schedule A Consultation</a>
                        </div>
                      <div class="header3-btn">
                        <a href="tel:281-378-7496">Call Us:
                            <span>281-378-7496</span></a>
                      </div>
                 </div>
              </div>
            </div>

            <div class="col-lg-6 col-md-12 text-center">
                <div class="hero3-image-all">
                    <div class="hero3-img1 img100 border-70">
                        <img src="assets/img/image/header3-main-img2.png" alt="">
                    </div>
                    <div class="hero3-img2 border50">
                        <img src="assets/img/image/header3-main-img.png" alt="">
                    </div>
                    <div class="hero3-img3 aniamtion-key-2">
                        <div class="header-icon-box">
                          <div class="header-icon">
                            <img src="assets/img/icons/header3-icon1.svg" alt="">
                          </div>
                          <div class="header-icon-text">
                            <p>24/7 Hours Support</p>
                          </div>
                        </div>
                    </div>
                    <div class="hero3-img4 aniamtion-key-2">
                      <div class="header-icon-box">
                        <div class="header-icon">
                          <img src="assets/img/icons/header3-icon2.svg" alt="">
                        </div>
                        <div class="header-icon-text">
                          <p>24/7 Hours Support</p>
                        </div>
                      </div>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
  `,
  styles: ``
})
export class HeroComponent {

}
