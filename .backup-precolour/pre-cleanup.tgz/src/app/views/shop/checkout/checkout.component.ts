import { Component } from '@angular/core';
import { BreadcrumbComponent } from "../../../components/breadcrumb.component";
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BodyClassDirective } from "../../../directive/body-class.directive";

@Component({
  selector: 'app-checkout',
  imports: [BreadcrumbComponent, CommonModule, FormsModule, BodyClassDirective],
  templateUrl: './checkout.component.html',
  styles: ``
})
export class CheckoutComponent {

  selectedPayment: string = '';


}
