import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-case-right',
  imports: [RouterLink],
  template: `
    <div class="service-details-post-all">
  <div class="img100">
    <img src="assets/img/image/case-details-img1.png" alt="" />
  </div>
  <div class="space30"></div>
  <div class="page-hadding">
    <h2>HR Compliance and Policies</h2>
    <div class="space14"></div>
    <p>
      Our track record speaks for itself.We have helped numerou organizations
      achieve tangible result including improved employee engagement, increased
      productivity, and enhanced organizational performance. Comprehensive
      Approach: We take a holistic view of your HR function and consider the
      interconnectednes of various HR areas. Our integrated approach ensures
      that your HR strategies align with your overall business objectives.
    </p>
  </div>

  <div class="row">
    <div class="col-lg-6">
      <div class="space30"></div>
      <div class="img100">
        <img src="assets/img/image/case-details-img2.png" alt="" />
      </div>
    </div>
    <div class="col-lg-6">
      <div class="space30"></div>
      <div class="img100">
        <img src="assets/img/image/case-details-img3.png" alt="" />
      </div>
    </div>
  </div>
  <div class="space30"></div>
  <div class="page-hadding">
    <h2>Our Solutions</h2>
    <div class="space14"></div>
    <p>
      on the Internet tend to repeat predefined chunks as necessary, making this
      the first true generator on the Internet. With more than 20 years of
      experience we can deliver the best services cum soluta nobis est eligendi
      optio cumque nihil impedit quo minus id quod maxime placeat facere
      possimus.
    </p>
  </div>

  <div class="row">
    <div class="col-lg-6">
      <div class="case-details-icon-box">
        <div class="case-box-icon">
          <span>1</span>
        </div>
        <div class="page-hadding">
          <h4><a [routerLink]="[]">First appointment</a></h4>
          <div class="space8"></div>
          <p>
            We understand the unique HR challenge faced by technology companie
            and startups.Our expertise in talent acquisition,
          </p>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="case-details-icon-box">
        <div class="case-box-icon">
          <span>2</span>
        </div>
        <div class="page-hadding">
          <h4><a [routerLink]="[]">Project Brief</a></h4>
          <div class="space8"></div>
          <p>
            We understand the unique HR challenge faced by technology companie
            and startups.Our expertise in talent acquisition,
          </p>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="case-details-icon-box">
        <div class="case-box-icon">
          <span>3</span>
        </div>
        <div class="page-hadding">
          <h4><a [routerLink]="[]">Financial Analysis </a></h4>
          <div class="space8"></div>
          <p>
            We understand the unique HR challenge faced by technology companie
            and startups.Our expertise in talent acquisition,
          </p>
        </div>
      </div>
    </div>

    <div class="col-lg-6">
      <div class="case-details-icon-box">
        <div class="case-box-icon">
          <span>4</span>
        </div>
        <div class="page-hadding">
          <h4><a [routerLink]="[]">Campaign Design</a></h4>
          <div class="space8"></div>
          <p>
            We understand the unique HR challenge faced by technology companie
            and startups.Our expertise in talent acquisition,
          </p>
        </div>
      </div>
    </div>
  </div>

  <div class="space30"></div>
  <div class="page-hadding">
    <p>
      We guide our clients through difficult issues, bringing insight and
      judgment to each situation. Our innovativ approache create original
      solutions to our clients most complex domestic & juristictional deals and
      dispute By thinking on behalf of our clients every day, we anticipate what
      they want, provide what they need and build lasting relationships.
      Customize your pour with an added boost of vitamins,
    </p>
  </div>
</div>

  `,
  styles: ``
})
export class CaseRightComponent {

}
