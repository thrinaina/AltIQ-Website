import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-about',
  host: { 'app-about': 'app-about3' },
  imports: [RouterLink],
  template: `
    <div class="about3 sp3" id="about">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="about3-images">
                        <div class="about3-img1 img100" data-aos="zoom-out" data-aos-duration="700">
                            <img src="assets/img/image/about3-img1.png" alt="">
                        </div>
                        <div class="about3-img2" data-aos="flip-up" data-aos-duration="800">
                            <img src="assets/img/image/about3-img2.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="hadding3 about-hadding3">
                        <h1 data-aos="fade-left" data-aos-duration="700">Partner with Our Trusted Consultants Today.</h1>
                        <div class="space24"></div>
                        <p data-aos="fade-left" data-aos-duration="800">At Toxa  tax Consulting Company, we are a trusted tax consulting firm with over 15 years of experience. Our mission is to provide exceptional tax services, personalized attention, and expert guidance to individuals and businesses. Our team of seasoned professionals</p>
                        <div class="space20"></div>
                        <p data-aos="fade-left" data-aos-duration="1000">has in-depth knowledge of tax laws,regulations, and industry best practices. We stay up-to-date with the latest changes in tax legislation to ensure we provide accurate and reliable advice.</p>

                        <div class="space40"></div>
                        <a class="buttonBox2 fifth" routerLink="/about">About Us</a>
                    </div>
                </div>
            </div>
        </div>
      </div>
  `,
  styles: ``
})
export class AboutComponent {

}
