import { Component } from '@angular/core';
import { BreadcrumbComponent } from '../../../components/breadcrumb.component';
import { BlogDetailsLeftComponent } from '../components/blog-details-left.component';
import { BlogDetailsRightComponent } from '../components/blog-details-right.component';
import { BodyClassDirective } from "../../../directive/body-class.directive";


@Component({
  selector: 'app-blog-details-sidebar-left',
  imports: [
    BreadcrumbComponent,
    BlogDetailsLeftComponent,
    BlogDetailsRightComponent,
    BodyClassDirective
],
  templateUrl: './blog-details-sidebar-left.component.html',
  styles: ``,
})
export class BlogDetailsSidebarLeftComponent {

}
