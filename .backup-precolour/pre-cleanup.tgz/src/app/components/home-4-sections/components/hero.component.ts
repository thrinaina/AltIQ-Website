import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-hero',
  host: { 'app-hero': 'app-hero4' },
  imports: [RouterLink],
  template: `
   <div class="main-hero main-hero3" style="background-color: var(--aiq-950);">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-lg-6 col-md-12">
              <div class="main-hadding4">
                <h1>Expert Tax Consulting Services for Individual and Businesses.</h1>
                <div class="space24"></div>
                <p>Maximize Your Tax Saving and Ensure Compliance.We help businesses to perform with our customized solutions helping them take business decisions.</p>
                <div class="space40"></div>
                <div class="header3-buttons">
                    <div class="header4-button">
                        <a routerLink="/contact" class="button4-header">Schedule A Consultation</a>
                        <a routerLink="/about" class="header4-button4">Learn More</a>
                      </div>
                 </div>
              </div>
            </div>
            <div class="col-lg-6 col-md-12 text-center">
                <div class="hero4-image-all">
                    <div class="hero4-img1 aniamtion-key-1">
                        <img src="assets/img/shapes/header4-shape.svg" alt="">
                    </div>
                    <div class="hero4-img2">
                        <img src="assets/img/image/header4-main-img.png" alt="">
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
  `,
  styles: ``
})
export class HeroComponent {

}
