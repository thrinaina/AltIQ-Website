import { Component } from '@angular/core';
import { NavbarComponent } from "./components/navbar.component";
import { BodyClassDirective } from "../../directive/body-class.directive";
import { Home8SectionsComponent } from '../../components/home-8-sections/home-8-sections.component';

@Component({
  selector: 'app-home-8',
  imports: [NavbarComponent, Home8SectionsComponent ,BodyClassDirective],
  templateUrl: './home-8.component.html',
  styles: ``,
})
export class Home8Component {

}
