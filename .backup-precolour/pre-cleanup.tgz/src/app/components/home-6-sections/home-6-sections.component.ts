import { Component } from '@angular/core';
import { HeroComponent } from './components/hero.component';
import { AboutComponent } from './components/about.component';
import { ServicesComponent } from './components/services.component';
import { CaseStudyComponent } from './components/case-study.component';
import { TestimonialComponent } from './components/testimonial.component';
import { BlogComponent } from './components/blog.component';
import { ContactComponent } from './components/contact.component';
import { CtaComponent } from './components/cta.component';
import { FooterComponent } from './components/footer.component';

@Component({
  selector: 'app-home-6-sections',
  imports: [HeroComponent,AboutComponent, ServicesComponent, CaseStudyComponent, TestimonialComponent, BlogComponent,ContactComponent,CtaComponent,FooterComponent],
  templateUrl: './home-6-sections.component.html',
  styles: ``
})
export class Home6SectionsComponent {

}
