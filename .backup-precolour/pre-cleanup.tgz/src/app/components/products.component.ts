import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

type ProductType = {
  image: string;
  name: string;
  oldprice?: string;
  price: string;
};

@Component({
  selector: 'app-products',
  imports: [RouterLink],
  template: `
    <div class="sp5">
      <div class="container">
        <div class="row">
          <div class="col-lg-7 m-auto text-center">
            <div class="page-hadding">
              <h1>Related Products</h1>
              <div class="space16"></div>
              <p>
                Consulting service is a key part of the future of energy. It can
                help you save money on your electricity bill, and it can also
                help to reduce your carbon footprint.
              </p>
            </div>
          </div>
        </div>
        <div class="space30"></div>
        <div class="row">
          @for(item of productData;track $index ){
          <div class="col-lg-3 col-md-6">
            <div class="shop-single-box">
              <div class="shop-img _relative">
                <div class="shop-img-single img100">
                  <img [src]="item.image" alt="" />
                </div>

                <div class="shop-box-hover-effect">
                  <a routerLink="/cart" class="comon-button">Add to Cart</a>
                </div>
              </div>
              <div class="space24"></div>
              <div class="shop-hadding">
                <h4>
                  <a routerLink="/cart">{{ item.name }}</a>
                </h4>
                <div class="shop-box-border"></div>
                <p>
                  <s>{{ item.oldprice }}</s
                  >{{ item.price }}
                </p>
              </div>
            </div>
          </div>
          }
        </div>
      </div>
    </div>
  `,
  styles: ``,
})
export class ProductsComponent {

  productData: ProductType[] = [
    {
      image: 'assets/img/shop/shop-img1.png',
      name: 'Chair and pillow',
      oldprice: '$1200',
      price: '$1100',
    },
    {
      image: 'assets/img/shop/shop-img2.png',
      name: 'Armchair and pillow',
      price: '$1000',
    },
    {
      image: 'assets/img/shop/shop-img3.png',
      name: 'Stylish grey chair',
      price: '$2200',
    },
    {
      image: 'assets/img/shop/shop-img4.png',
      name: 'Old wooden armchair',
      price: '$1500',
    },
  ];
  
}
