import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseDetails1Component } from './case-details1.component';

describe('CaseDetails1Component', () => {
  let component: CaseDetails1Component;
  let fixture: ComponentFixture<CaseDetails1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CaseDetails1Component]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CaseDetails1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
