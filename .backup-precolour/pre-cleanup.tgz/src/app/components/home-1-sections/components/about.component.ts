import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-about',
  host: { 'app-about': 'app-about1' },
  imports: [RouterLink],
  template: `
   <div class="about2 sp3" id="about">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="about2-images">
                        <div class="about2-img1 aniamtion-key-1">
                            <img src="assets/img/shapes/home2-main-shape.svg" alt="">
                        </div>
                        <div class="about2-img2 border-70" data-aos="zoom-out" data-aos-duration="800">
                            <img src="assets/img/image/about2-image.png" alt="">
                        </div>
                    </div>
                </div>    
                <div class="col-lg-6">
                    <div class="hadding2 about2-hadding">
                        <span class="span" data-aos="fade-left" data-aos-duration="700">About Us</span>
                        <div class="space16"></div>
                        <h1 data-aos="fade-left" data-aos-duration="800">Partner with Our <span class="after2">Trusted</span> Consultants Today.</h1>
                        <div class="space24"></div>
                        <p data-aos="fade-left" data-aos-duration="1000">At Advisor Consulting Company, we are a trusted business consulting firm dedicated to helping businesses thrive and reach their full potential.
                            Our team of experienced consultants brings diverse industry knowledge and expertise in various business disciplines.We prioritize understanding</p>
                        <div class="space20"></div>
                        <p data-aos="fade-left" data-aos-duration="700">your unique challenges and goals to deliver customized solutions tailored to your specific needsWe are committed to providing exceptional service innovative strategies, and tangible results for our clients.</p>

                        <div class="space40"></div>
                        <a routerLink="/about" class="button-h-2 btnfos2">About Us</a>
                    </div>
                </div>
            </div>
        </div>
      </div>
  `,
  styles: ``
})
export class AboutComponent {
  
} 
