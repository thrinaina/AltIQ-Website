import { Component } from '@angular/core';
import { BreadcrumbComponent } from '../../../components/breadcrumb.component';
import { BodyClassDirective } from "../../../directive/body-class.directive";

@Component({
  selector: 'app-account2',
  imports: [BreadcrumbComponent, BodyClassDirective],
  templateUrl: './account2.component.html',
  styles: ``,
})
export class Account2Component {
 
}
