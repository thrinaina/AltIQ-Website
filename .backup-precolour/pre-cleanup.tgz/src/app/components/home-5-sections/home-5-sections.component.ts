import { Component } from '@angular/core';
import { HeroComponent } from "./components/hero.component";
import { ServicesComponent } from "./components/services.component";
import { IndustriesComponent } from "./components/industries.component";
import { TestimonialComponent } from "./components/testimonial.component";
import { BlogComponent } from "./components/blog.component";
import { ContactComponent } from "./components/contact.component";
import { FooterComponent } from "./components/footer.component";
import { AboutComponent } from "./components/about.component";

@Component({
  selector: 'app-home-5-sections',
  imports: [HeroComponent, AboutComponent ,ServicesComponent, IndustriesComponent, TestimonialComponent, BlogComponent, ContactComponent, FooterComponent],
  templateUrl: './home-5-sections.component.html',
  styles: ``
})
export class Home5SectionsComponent {

}
