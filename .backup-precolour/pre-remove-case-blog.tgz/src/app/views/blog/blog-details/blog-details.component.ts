import { Component } from '@angular/core';
import { BreadcrumbComponent } from '../../../components/breadcrumb.component';
import { BlogDetailsRightComponent } from '../components/blog-details-right.component';
import { BodyClassDirective } from "../../../directive/body-class.directive";


@Component({
  selector: 'app-blog-details',
  imports: [BreadcrumbComponent, BlogDetailsRightComponent, BodyClassDirective],
  templateUrl: './blog-details.component.html',
  styles: ``,
})
export class BlogDetailsComponent {

}
