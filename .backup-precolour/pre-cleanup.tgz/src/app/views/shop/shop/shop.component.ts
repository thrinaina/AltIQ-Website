import { Component } from '@angular/core';
import { BreadcrumbComponent } from '../../../components/breadcrumb.component';
import { RouterLink } from '@angular/router';
import { ThemePaginationComponent } from "../../../components/theme-pagination.component";
import { BodyClassDirective } from "../../../directive/body-class.directive";

type shopType = {
  image: string;
  title: string;
  oldprice?: string;
  price: string;
};

@Component({
  selector: 'app-shop',
  imports: [BreadcrumbComponent, RouterLink, ThemePaginationComponent, BodyClassDirective],
  templateUrl: './shop.component.html',
  styles: ``,
})
export class ShopComponent {

  

  shopData: shopType[] = [
    {
      image: 'assets/img/shop/shop-img1.png',
      title: 'Chair and pillow',
      oldprice: '$1200',
      price: '$1100',
    },
    {
      image: 'assets/img/shop/shop-img2.png',
      title: 'Armchair and pillow',
      price: '$1000',
    },
    {
      image: 'assets/img/shop/shop-img3.png',
      title: 'Stylish grey chair',
      price: '$2200',
    },
    {
      image: 'assets/img/shop/shop-img4.png',
      title: 'Old wooden armchair',
      price: '$1500',
    },
    {
      image: 'assets/img/shop/shop-img5.png',
      title: 'Armchair and pillow',
      oldprice: '$2200',
      price: '$2000',
    },
    {
      image: 'assets/img/shop/shop-img6.png',
      title: 'Stylish grey chair',
      price: '$2200',
    },
    {
      image: 'assets/img/shop/shop-img7.png',
      title: 'Red vintage armchair',
      oldprice: '$2100',
      price: '$1900',
    },
    {
      image: 'assets/img/shop/shop-img8.png',
      title: 'Armchair and pillow',
      price: '$1800',
    },
    {
      image: 'assets/img/shop/shop-img9.png',
      title: 'Comfort modern chair',
      price: '$2500',
    },
    {
      image: 'assets/img/shop/shop-img10.png',
      title: 'Old wooden armchair',
      price: '$1500',
    },
    {
      image: 'assets/img/shop/shop-img11.png',
      title: 'Armchair and pillow',
      price: '$1100',
    },
    {
      image: 'assets/img/shop/shop-img12.png',
      title: 'Stylish grey chair',
      price: '$2200',
    },
  ];
  
}
