import { Component } from '@angular/core';
import { NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-theme-pagination',
  imports: [NgbPaginationModule],
  template: `
    <div class="col-12">
      <div class="d-flex align-items-center justify-content-center">
        <div class="theme-pagination text-center">
          <ngb-pagination
            [(page)]="currentPage"
            [collectionSize]="totalItems"
            [pageSize]="pageSize"
            [maxSize]="2"
          >
            <ng-template ngbPaginationPrevious>
              <i class="fa-solid fa-angles-left"></i>
            </ng-template>
            <ng-template ngbPaginationNext>
              <i class="fa-solid fa-angles-right"></i>
            </ng-template>
          </ngb-pagination>
        </div>
      </div>
    </div>
  `,
  styles: ``,
})
export class ThemePaginationComponent {
  totalItems = 120;
  pageSize = 10;
  currentPage = 1;
}
