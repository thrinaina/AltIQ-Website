import { Component } from '@angular/core';
import { BreadcrumbComponent } from "../../../components/breadcrumb.component";
import { BlogRightComponent } from '../components/blog-right.component';
import { BlogLeftComponent } from '../components/blog-left.component';
import { BodyClassDirective } from "../../../directive/body-class.directive";

@Component({
  selector: 'app-blog-sidebar-right',
  imports: [BreadcrumbComponent, BlogRightComponent, BlogLeftComponent, BodyClassDirective],
  templateUrl: './blog-sidebar-right.component.html',
  styles: ``
})
export class BlogSidebarRightComponent {

}
