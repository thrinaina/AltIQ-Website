import { Component } from '@angular/core';
import { BreadcrumbComponent } from '../../../components/breadcrumb.component';
import { RouterLink } from '@angular/router';
import { BodyClassDirective } from "../../../directive/body-class.directive";

@Component({
  selector: 'app-account',
  imports: [BreadcrumbComponent, RouterLink, BodyClassDirective],
  templateUrl: './account.component.html',
  styles: ``,
})
export class AccountComponent {

}
