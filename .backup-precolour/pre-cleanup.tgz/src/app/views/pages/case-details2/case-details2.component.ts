import { Component } from '@angular/core';
import { CaseProjectsComponent } from '../case-projects/case-projects.component';
import { BreadcrumbComponent } from '../../../components/breadcrumb.component';
import { CaseRightComponent } from '../components/case-right.component';
import { CaseLeftComponent } from '../components/case-left.component';
import { BodyClassDirective } from "../../../directive/body-class.directive";

@Component({
  selector: 'app-case-details2',
  imports: [
    CaseProjectsComponent,
    CaseRightComponent,
    CaseLeftComponent,
    BreadcrumbComponent,
    BodyClassDirective
],
  templateUrl: './case-details2.component.html',
  styles: ``,
})
export class CaseDetails2Component {

}
