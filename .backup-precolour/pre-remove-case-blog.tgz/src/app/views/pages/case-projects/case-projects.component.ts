import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

type projectType = {
  image: string;
  title: string;
  des: string;
};

@Component({
  selector: 'app-case-projects',
  imports: [RouterLink],
  templateUrl: './case-projects.component.html',
  styles: ``,
})
export class CaseProjectsComponent {

  projectData: projectType[] = [
    {
      image: 'assets/img/image/case1-img1.png',
      title: 'Financial Investment',
      des: 'Describe the HR challenges faced by the client and how your the solutions helped them achieve significant',
    },
    {
      image: 'assets/img/image/case1-img2.png',
      title: 'HR Consulting',
      des: 'Describe the HR challenges faced by the client and how your the solutions helped them achieve significant',
    },
  ];
  
}
