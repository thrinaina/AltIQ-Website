import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-about',
  host: { 'app-about': 'app-single-about8' },
  imports: [RouterLink],
  template: `
    <div class="about8 sp3" id="about">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6">
            <div
              class="about8-images _relative"
              data-aos="zoom-out"
              data-aos-duration="700"
            >
              <div class="about8-shape">
                <img src="assets/img/shapes/hero8-shape2.svg" alt="" />
              </div>
              <div class="about8-img img100 img5">
                <img src="assets/img/image/about8-img.png" alt="" />
              </div>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="hadding8 about8-hadding">
              <span data-aos="fade-left" data-aos-duration="700">About Us</span>
              <div class="space16"></div>
              <h1 data-aos="fade-left" data-aos-duration="900">
                Partner with Our Trusted to Consultants Today
              </h1>
              <div class="space20"></div>
              <p data-aos="fade-left" data-aos-duration="1100">
                At Advisor Consulting Company, we are a trusted business
                consulting firm dedicated to helping businesses thrive and reach
                their full potential. Consult our team of experienced
                consultants brings diverse industry knowledge & expertise in
                various business disciplines. We prioritize understanding
              </p>
              <div class="space20"></div>
              <p data-aos="fade-left" data-aos-duration="800">
                Your unique challenges and goals to deliver customized solutions
                tailored to your specific needs We are committed to providing
                exceptional service innovative strategies, and tangible results
                for our clients.
              </p>
              <div class="space32"></div>
              <div class="" data-aos="fade-left" data-aos-duration="1000">
                <a routerLink="service" class="theme-btn10"
                  >Discover Our Services</a
                >
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: ``,
})
export class AboutComponent {}
