import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShopSidebarRightComponent } from './shop-sidebar-right.component';

describe('ShopSidebarRightComponent', () => {
  let component: ShopSidebarRightComponent;
  let fixture: ComponentFixture<ShopSidebarRightComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShopSidebarRightComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShopSidebarRightComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
