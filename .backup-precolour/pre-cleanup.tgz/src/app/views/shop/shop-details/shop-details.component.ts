import { Component } from '@angular/core';
import { BreadcrumbComponent } from '../../../components/breadcrumb.component';
import { RouterLink } from '@angular/router';
import { NgbNavModule } from '@ng-bootstrap/ng-bootstrap';
import { ProductsComponent } from "../../../components/products.component";
import { BodyClassDirective } from "../../../directive/body-class.directive";

@Component({
  selector: 'app-shop-details',
  imports: [BreadcrumbComponent, RouterLink, NgbNavModule, ProductsComponent, BodyClassDirective],
  templateUrl: './shop-details.component.html',
  styles: ``,
})
export class ShopDetailsComponent {


  quantity: number = 1;

  increment(): void {
    this.quantity++;
  }

  decrement(): void {
    if (this.quantity > 1) {
      this.quantity--;
    }
  }

  socialIcon: string[]  = [
    "fa-brands fa-twitter",
    "fa-brands fa-facebook-f",
    "fa-brands fa-instagram",
    "fa-brands fa-github"
  ]
}
