import { Component } from '@angular/core';
import { NavbarComponent } from "./components/navbar.component";
import { BodyClassDirective } from "../../directive/body-class.directive";
import { Home5SectionsComponent } from "../../components/home-5-sections/home-5-sections.component";

@Component({
  selector: 'app-home-5',
  host: { 'app-home': 'app-single-home5' },
  imports: [NavbarComponent, BodyClassDirective, Home5SectionsComponent],
  templateUrl: './home-5.component.html',
  styles: ``,
})
export class Home5Component {

}
