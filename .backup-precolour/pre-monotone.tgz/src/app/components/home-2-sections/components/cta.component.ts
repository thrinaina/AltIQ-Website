import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-cta',
  host: { 'app-cta': 'app-cta2' },
  imports: [RouterLink],
  template: `
   <div class="subscribe1 sp3" style="background-color: #03163B; padding: 80px 0">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-lg-6">
              <div class="cta-hadding1">
                <h1 class="font-w" data-aos="fade-right" data-aos-duration="700">Take advantage of a consultation</h1>
                <div class="space24"></div>
                <p data-aos="fade-right" data-aos-duration="900">Take advantage of a one on one consultation with our tax experts. We'll assess your unique situation and provide personalized advice and strategies.</p>
              </div>
            </div>
            <div class="col-lg-6 text-right">
                <div class="cta1-buttons">
                  <a routerLink="/service-details" data-aos="fade-up" data-aos-duration="700" class="btn_theme2 btn_theme btn_theme2 btn_theme_active2 wow fadeInDown1" data-wow-duration="0.8s">Schedule A Consultation<span></span></a>
                  <a routerLink="/service-details" data-aos="fade-up" data-aos-duration="900" class="btn_theme3 btn_theme btn_theme_active3 wow fadeInDown2" data-wow-duration="0.8s">Contact Us<span></span></a>
                </div>
            </div>
          </div>
        </div>
        <div class="subscribe-img aniamtion-key-1">
          <img src="assets/img/shapes/counter-shape.svg" alt="">
        </div>
      </div>
  `,
  styles: ``
})
export class CtaComponent {

}
