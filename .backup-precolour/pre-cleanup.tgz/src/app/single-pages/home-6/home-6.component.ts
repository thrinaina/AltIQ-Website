import { Component } from '@angular/core';

import { NavbarComponent } from "./components/navbar.component";
import { BodyClassDirective } from "../../directive/body-class.directive";
import { Home6SectionsComponent } from '../../components/home-6-sections/home-6-sections.component';

@Component({
  selector: 'app-home-6',
  host: { 'app-home': 'app-single-home6' },
  imports: [NavbarComponent,  BodyClassDirective, Home6SectionsComponent],
  templateUrl: './home-6.component.html',
  styles: ``,
})
export class Home6Component {
  
}
