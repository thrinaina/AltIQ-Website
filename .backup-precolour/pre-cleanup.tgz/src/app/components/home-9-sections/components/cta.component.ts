import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-cta',
  host: { 'app-cta': 'app-single-cta9' },
  imports: [RouterLink],
  template: `
     <div class="cta9">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-lg-7">
              <div class="hadding7-w">
                <h1>Transform Your HR Practices?</h1>
                <div class="space16"></div>
                <p>Unlock the full potential of your workforce with our tailored HR manage consulting services. Whether you're looking to optimize recruitment, enhance employe.</p>
              </div>
            </div>
            <div class="col-lg-5">
              <div class="cta6-buttons">
                <a routerLink="/service" class="cta9-btn1">Request HR Consultation <span><i class="fa-solid fa-arrow-right"></i></span></a>
                <a routerLink="/contact" class="cta9-btn2">Contact Us <span><i class="fa-solid fa-arrow-right"></i></span></a>
              </div>
            </div>
          </div>
        </div>
       </div>
  `,
  styles: ``
})
export class CtaComponent {

}
