import { Route } from '@angular/router';
import { Home1Component } from './home-1/home-1.component';
import { Home2Component } from './home-2/home-2.component';
import { Home3Component } from './home-3/home-3.component';
import { Home4Component } from './home-4/home-4.component';
import { Home5Component } from './home-5/home-5.component';
import { Home6Component } from './home-6/home-6.component';
import { Home7Component } from './home-7/home-7.component';
import { Home8Component } from './home-8/home-8.component';
import { Home9Component } from './home-9/home-9.component';
import { Home10Component } from './home-10/home-10.component';

export const MULTI_PAGES_ROUTES: Route[] = [
  {
    path: 'multi/home-1',
    component: Home1Component,
    data: { title: 'Home 1 || Business Consulting' },
  },
  {
    path: 'multi/home-2',
    component: Home2Component,
    data: { title: 'Home 2 || Advisr Tax Consulting' },
  },
  {
    path: 'multi/home-3',
    component: Home3Component,
    data: { title: 'Home 3 || Tax Consulting' },
  },
  {
    path: 'multi/home-4',
    component: Home4Component,
    data: { title: 'Home 4 || Finance Consulting' },
  },
  {
    path: 'multi/home-5',
    component: Home5Component,
    data: { title: 'Home 5 || Business Consulting' },
  },
  {
    path: 'multi/home-6',
    component: Home6Component,
    data: { title: 'Home 6 || Business Consulting' },
  },
  {
    path: 'multi/home-7',
    component: Home7Component,
    data: { title: 'Home 7 || Business Consulting' },
  },
  {
    path: 'multi/home-8',
    component: Home8Component,
    data: { title: 'Home 8 || Business Consulting' },
  },
  {
    path: 'multi/home-9',
    component: Home9Component,
    data: { title: 'Home 9 || Business Consulting' },
  },
  {
    path: 'multi/home-10',
    component: Home10Component,
    data: { title: 'Home 10 || Business Consulting' },
  },
];
