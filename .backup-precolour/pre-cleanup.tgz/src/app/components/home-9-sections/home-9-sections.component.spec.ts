import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home9SectionsComponent } from './home-9-sections.component';

describe('Home9SectionsComponent', () => {
  let component: Home9SectionsComponent;
  let fixture: ComponentFixture<Home9SectionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Home9SectionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Home9SectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
