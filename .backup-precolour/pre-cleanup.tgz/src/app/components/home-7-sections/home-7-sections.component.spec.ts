import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home7SectionsComponent } from './home-7-sections.component';

describe('Home7SectionsComponent', () => {
  let component: Home7SectionsComponent;
  let fixture: ComponentFixture<Home7SectionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Home7SectionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Home7SectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
