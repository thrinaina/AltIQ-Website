import { Component } from '@angular/core';
import { BreadcrumbComponent } from '../../../components/breadcrumb.component';
import { ShopRightComponent } from '../components/shop-right.component';
import { ShopLeftComponent } from '../components/shop-left.component';
import { BodyClassDirective } from "../../../directive/body-class.directive";


@Component({
  selector: 'app-shop-sidebar-right',
  imports: [BreadcrumbComponent, ShopRightComponent, ShopLeftComponent, BodyClassDirective],
  templateUrl: './shop-sidebar-right.component.html',
  styles: ``,
})
export class ShopSidebarRightComponent {

}
