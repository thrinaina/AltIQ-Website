import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

type servicesType = {
  image: string;
  duration: string;
  title: string;
  des: string;
};

@Component({
  selector: 'app-services',
  host: { 'app-services': 'app-single-services5' },
  imports: [RouterLink],
  template: `
    <div class="service5 sp3" id="service">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 m-auto text-center">
            <div class="hadding5">
              <h1 data-aos="fade-up" data-aos-duration="700">
                Services We Offered
              </h1>
              <div class="space16"></div>
              <p data-aos="fade-up" data-aos-duration="900">
                Our team of experienced consultants combines industry knowledge,
                cutting-edge technology, and innovative strategies to guide you
                a brighter.
              </p>
            </div>
          </div>
        </div>
        <div class="space30"></div>

        <div class="row">
          @for(item of servicesData;track $index){
          <div class="col-lg-3 col-md-6">
            <div
              class="service5-box"
              data-aos="fade-up"
              [attr.data-aos-duration]="item.duration"
            >
              <div class="service5-icon">
                <img [src]="item.image" alt="" />
              </div>
              <div class="space20"></div>
              <div class="hadding5">
                <h4>
                  <a routerLink="/service-details">{{ item.title }}</a>
                </h4>
                <div class="service5-border"></div>
                <p>
                  {{ item.des }}
                </p>

                <div class="space16"></div>
                <a routerLink="/service-details" class="learn-more5"
                  >Read More <i class="fa-solid fa-arrow-right"></i
                ></a>
              </div>
            </div>
          </div>
          }

          <div class="space40"></div>
          <div class="row">
            <div class="col-lg-12 text-center">
              <div class="" data-aos="fade-up" data-aos-duration="800">
                <a routerLink="/service" class="theme-btn5"
                  >View Our More Services<span
                    ><i class="fa-solid fa-angle-right"></i></span
                ></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: ``,
})
export class ServicesComponent {

  servicesData: servicesType[] = [
    {
      image: 'assets/img/icons/service5-icon1.svg',
      duration: '700',
      title: 'Financial Planning',
      des: 'We help optimize your capital structure by assessing your...',
    },
    {
      image: 'assets/img/icons/service5-icon2.svg',
      duration: '900',
      title: 'Investment Advisory',
      des: 'We assist in identifying and to mitigating financial risk...',
    },
    {
      image: 'assets/img/icons/service5-icon3.svg',
      duration: '1200',
      title: 'Tax Strategy',
      des: 'We help optimize your capital structure by assessing your...',
    },
    {
      image: 'assets/img/icons/service5-icon4.svg',
      duration: '800',
      title: 'Risk Management',
      des: 'We assist in identifying and to mitigating financial risk...',
    },
  ];
  
}
