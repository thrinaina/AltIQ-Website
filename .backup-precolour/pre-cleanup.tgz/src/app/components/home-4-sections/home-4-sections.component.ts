import { Component } from '@angular/core';
import { HeroComponent } from "./components/hero.component";
import { BrandsComponent } from "./components/brands.component";
import { AboutComponent } from "./components/about.component";
import { ServicesComponent } from "./components/services.component";
import { FeaturesComponent } from "./components/features.component";
import { TestimonialComponent } from "./components/testimonial.component";
import { CtaComponent } from "../cta.component";
import { BlogComponent } from "./components/blog.component";
import { Cta2Component } from "./components/cta2.component";
import { FooterComponent } from "./components/footer.component";

@Component({
  selector: 'app-home-4-sections',
  imports: [HeroComponent, BrandsComponent, AboutComponent, ServicesComponent, FeaturesComponent, TestimonialComponent, CtaComponent, BlogComponent, Cta2Component, FooterComponent],
  templateUrl: './home-4-sections.component.html',
  styles: ``
})
export class Home4SectionsComponent {

}
