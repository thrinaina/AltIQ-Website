import { Component } from '@angular/core';
import { BreadcrumbComponent } from '../../../components/breadcrumb.component';
import { BlogLeftComponent } from '../components/blog-left.component';
import { BlogRightComponent } from '../components/blog-right.component';
import { BodyClassDirective } from "../../../directive/body-class.directive";


@Component({
  selector: 'app-blog-sidebar-left',
  imports: [BreadcrumbComponent, BlogLeftComponent, BlogRightComponent, BodyClassDirective],
  templateUrl: './blog-sidebar-left.component.html',
  styles: ``,
})
export class BlogSidebarLeftComponent {

}
