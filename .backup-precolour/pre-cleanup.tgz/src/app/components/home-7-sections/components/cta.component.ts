import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-cta',
  host: { 'app-cta': 'app-single-cta7' },
  imports: [RouterLink],
  template: `
     <div class="cta7">
        <div class="container">
          <div class="row align-items-center">
            <div class="col-lg-7">
              <div class="hadding7-w">
                <h1 class="font-f-7">Transform Your HR Practices?</h1>
                <div class="space16"></div>
                <p>Unlock the full potential of your workforce with our tailored HR manage consulting services. Whether you're looking to optimize recruitment, enhance employe.</p>
              </div>
            </div>
            <div class="col-lg-5">
              <div class="cta6-buttons">
                <a routerLink="/service" class="cta7-btn1">Request HR Consultation</a>
                <a routerLink="/contact" class="cta7-btn2">Contact Us</a>
              </div>
            </div>
          </div>
        </div>
       </div>
  `,
  styles: ``
})
export class CtaComponent {

}
