import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

type footermenuType = {
  name: string;
  link?: string;
};

type socialIconType = {
  title: string;
  icon: string;
};

@Component({
  selector: 'app-footer',
  host: { 'app-footer': 'app-layout-footer' },
  imports: [RouterLink],
  templateUrl: './footer.component.html',
  styles: ``,
})
export class FooterComponent {
  currentYear: number = new Date().getFullYear();

  footermenu: footermenuType[] = [
    {
      name: 'Home',
      link: '/multi/home-1',
    },
    {
      name: 'About',
      link: '/about',
    },
    {
      name: 'Our Team',
    },
    {
      name: 'Blogs',
      link: '/blog',
    },
    {
      name: 'Contact',
      link: '/contact',
    },
  ];

  usefullinks: string[] = [
    'Strategy Consulting',
    'Financial Consulting',
    'Marketing Consulting',
    'Operations Consulting',
    'Marketing Consulting',
  ];

  socialIcons: socialIconType[] = [
    {
      title: 'Linked in',
      icon: 'fa-brands fa-facebook',
    },
    {
      title: 'Facebook',
      icon: 'fa-brands fa-linkedin-in',
    },
    {
      title: 'Instagram',
      icon: 'fa-brands fa-youtube',
    },
    {
      title: 'TikTok',
      icon: 'fa-brands fa-twitter',
    },
  ];
}
