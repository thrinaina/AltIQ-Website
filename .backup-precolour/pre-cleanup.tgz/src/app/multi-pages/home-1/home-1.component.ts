import { Component } from '@angular/core';
import { NavbarComponent } from "./components/navbar.component";
import { BodyClassDirective } from "../../directive/body-class.directive";
import { Home1SectionsComponent } from "../../components/home-1-sections/home-1-sections.component";

@Component({
  selector: 'app-home-1',
  imports: [NavbarComponent, BodyClassDirective, Home1SectionsComponent],
  templateUrl: './home-1.component.html',
  styles: ``
})
export class Home1Component {

}
