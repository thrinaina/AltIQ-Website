import { Component } from '@angular/core';
import { HeroComponent } from "./components/hero.component";
import { BrandsComponent } from "./components/brands.component";
import { ServicesComponent } from "./components/services.component";
import { AboutComponent } from "./components/about.component";
import { CaseStudiesComponent } from "./components/case-studies.component";
import { CounterComponent } from "./components/counter.component";
import { TestimonialComponent } from "./components/testimonial.component";
import { CtaComponent } from './components/cta.component';
import { BlogComponent } from "./components/blog.component";
import { FooterComponent } from "./components/footer.component";

@Component({
  selector: 'app-home-2-sections',
  imports: [HeroComponent, BrandsComponent, ServicesComponent, AboutComponent, CaseStudiesComponent, CounterComponent, TestimonialComponent, CtaComponent, BlogComponent, FooterComponent],
  templateUrl: './home-2-sections.component.html',
  styles: ``
})
export class Home2SectionsComponent {

}
