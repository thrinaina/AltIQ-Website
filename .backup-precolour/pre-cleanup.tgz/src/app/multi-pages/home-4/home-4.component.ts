import { Component } from '@angular/core';
import { NavbarComponent } from "./components/navbar.component";
import { BodyClassDirective } from "../../directive/body-class.directive";
import { Home4SectionsComponent } from "../../components/home-4-sections/home-4-sections.component";

@Component({
  selector: 'app-home-4',
  imports: [NavbarComponent, Home4SectionsComponent ,BodyClassDirective],
  templateUrl: './home-4.component.html',
  styles: ``
})
export class Home4Component {

}
