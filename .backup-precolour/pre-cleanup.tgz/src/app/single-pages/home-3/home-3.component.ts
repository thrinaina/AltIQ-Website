import { Component } from '@angular/core';
import { NavbarComponent } from "./components/navbar.component";
import { BodyClassDirective } from "../../directive/body-class.directive";
import { Home3SectionsComponent } from "../../components/home-3-sections/home-3-sections.component";

@Component({
  selector: 'app-home-3',
  host: { 'app-home': 'app-single-home3' },
  imports: [NavbarComponent, BodyClassDirective, Home3SectionsComponent],
  templateUrl: './home-3.component.html',
  styles: ``
})

export class Home3Component {

}
