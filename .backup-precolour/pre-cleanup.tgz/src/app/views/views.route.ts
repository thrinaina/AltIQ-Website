import { Route } from '@angular/router';
import { AboutComponent } from './about/about.component';
import { ServiceComponent } from './services/service/service.component';
import { Service2Component } from './services/service2/service2.component';
import { ServiceDetailsComponent } from './services/service-details/service-details.component';
import { CaseComponent } from './pages/case/case.component';
import { CaseDetails1Component } from './pages/case-details1/case-details1.component';
import { CaseDetails2Component } from './pages/case-details2/case-details2.component';
import { FaqComponent } from './pages/faq/faq.component';
import { ErrorComponent } from './pages/error/error.component';
import { ShopComponent } from './shop/shop/shop.component';
import { ShopSidebarLeftComponent } from './shop/shop-sidebar-left/shop-sidebar-left.component';
import { ShopSidebarRightComponent } from './shop/shop-sidebar-right/shop-sidebar-right.component';
import { CartComponent } from './shop/cart/cart.component';
import { CheckoutComponent } from './shop/checkout/checkout.component';
import { AccountComponent } from './shop/account/account.component';
import { Account2Component } from './shop/account2/account2.component';
import { ShopDetailsComponent } from './shop/shop-details/shop-details.component';
import { BlogComponent } from './blog/blog/blog.component';
import { Blog2Component } from './blog/blog2/blog2.component';
import { BlogSidebarLeftComponent } from './blog/blog-sidebar-left/blog-sidebar-left.component';
import { BlogSidebarRightComponent } from './blog/blog-sidebar-right/blog-sidebar-right.component';
import { BlogDetailsSidebarLeftComponent } from './blog/blog-details-sidebar-left/blog-details-sidebar-left.component';
import { BlogDetailsSidebarRightComponent } from './blog/blog-details-sidebar-right/blog-details-sidebar-right.component';
import { BlogDetailsComponent } from './blog/blog-details/blog-details.component';
import { ContactComponent } from './contact/contact.component';

export const VIEWS_ROUTE: Route[] = [
  {
    path: 'about',
    component: AboutComponent,
    data: { title: 'About || Advisr Tax Consulting' }
  },
  {
    path: 'service',
    component: ServiceComponent,
    data: { title: 'Service || Advisr Tax Consulting' }

  },
  {
    path: 'service2',
    component: Service2Component,
    data: { title: 'Service 2 || Advisr Tax Consulting' }

  },
  {
    path: 'service-details',
    component: ServiceDetailsComponent,
    data: { title: 'Service Details || Advisr Tax Consulting' }

  },
  {
    path: 'case',
    component: CaseComponent,
    data: { title: 'Case Study || Advisr Tax Consulting' }

  },
  {
    path: 'case-details1',
    component: CaseDetails1Component,
    data: { title: 'Case Dtails 1 || Advisr Tax Consulting' }

  },
  {
    path: 'case-details2',
    component : CaseDetails2Component,
    data: { title: 'Case Dtails 2 || Advisr Tax Consulting' }
  },
  {
    path: 'faq',
    component : FaqComponent,
    data: { title: 'FAQ || Advisr Tax Consulting' }
  },
  {
    path: 'error',
    component: ErrorComponent,
    data: { title: '404 || Advisr Tax Consulting' }
  },
  {
    path : 'shop',
    component : ShopComponent,
    data: { title: 'Shop || Advisr Tax Consulting' }
  },
  {
    path : 'shop-sidebar-left',
    component : ShopSidebarLeftComponent,
    data: { title: 'Shop Sidebar Left || Advisr Tax Consulting' }
  },
  {
    path : 'shop-sidebar-right',
    component : ShopSidebarRightComponent,
    data: { title: 'Shop Sidebar Right || Advisr Tax Consulting' }
  },
  {
    path : 'cart',
    component : CartComponent,
    data: { title: 'Cart || Advisr Tax Consulting' }
  },
  {
    path : 'checkout',
    component : CheckoutComponent,
    data: { title: 'Checkout || Advisr Tax Consulting' }
  },
  {
    path : 'account',
    component : AccountComponent,
    data: { title: 'My Account || Advisr Tax Consulting' }
  },
  {
    path : 'account2',
    component : Account2Component,
    data: { title: 'My Account || Advisr Tax Consulting' }
  },
  {
    path : 'shop-details',
    component : ShopDetailsComponent,
    data: { title: 'Shop Details || Advisr Tax Consulting' }
  },
  {
    path : 'blog',
    component : BlogComponent,
    data: { title: 'Blog || Advisr Tax Consulting' }
  },
  {
    path : 'blog2',
    component : Blog2Component,
    data: { title: 'Blog 2 || Advisr Tax Consulting' }
  },
  {
    path : 'blog-sidebar-left',
    component : BlogSidebarLeftComponent,
    data: { title: 'Blog Sidebar Left || Advisr Tax Consulting' }
  },
  {
    path : 'blog-sidebar-right',
    component : BlogSidebarRightComponent,
    data: { title: 'Blog Sidebar Right || Advisr Tax Consulting' }
  },
  {
    path : 'blog-details-sidebar-left',
    component : BlogDetailsSidebarLeftComponent,
    data: { title: 'Blog Details Sidebar Left || Advisr Tax Consulting' }
  },
  {
    path : 'blog-details-sidebar-right',
    component : BlogDetailsSidebarRightComponent,
    data: { title: 'Blog Details Sidebar Right || Advisr Tax Consulting' }
  },
  {
    path : 'blog-details',
    component : BlogDetailsComponent,
    data: { title: 'Blog Details || Advisr Tax Consulting' }
  },
  {
    path : 'contact',
    component : ContactComponent,
    data: { title: 'Contact Us || Advisr Tax Consulting' }
  }
];
