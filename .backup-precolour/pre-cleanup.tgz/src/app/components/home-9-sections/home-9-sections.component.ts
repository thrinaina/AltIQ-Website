import { Component } from '@angular/core';
import { HeroComponent } from './components/hero.component';
import { AboutComponent } from './components/about.component';
import { ServicesComponent } from './components/services.component';
import { CounterComponent } from './components/counter.component';
import { CaseStudyComponent } from './components/case-study.component';
import { TestimonialComponent } from './components/testimonial.component';
import { ContactComponent } from './components/contact.component';
import { BlogComponent } from './components/blog.component';
import { CtaComponent } from './components/cta.component';
import { FooterComponent } from './components/footer.component';

@Component({
  selector: 'app-home-9-sections',
  imports: [HeroComponent,AboutComponent, ServicesComponent,CounterComponent,CaseStudyComponent,TestimonialComponent,ContactComponent,BlogComponent,CtaComponent,FooterComponent],
  templateUrl: './home-9-sections.component.html',
  styles: ``
})
export class Home9SectionsComponent {

}
