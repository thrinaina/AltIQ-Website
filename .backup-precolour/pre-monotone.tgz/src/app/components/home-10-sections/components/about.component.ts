import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { CountUpModule } from 'ngx-countup';

@Component({
  selector: 'app-about',
  host: { 'app-about': 'app-single-about10' },
  imports: [RouterLink, CountUpModule],
  template: `
    <div class="about9 sp3" id="about" style="background-color: #2B2C32;">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6">
            <div
              class="about9-images _relative"
              data-aos="zoom-out"
              data-aos-duration="800"
            >
              <div class="about9-img1 img100 img5">
                <img src="assets/img/image/about9-img.png" alt="" />
              </div>
              <div class="about9-img2">
                <h1 class="font-f-6">
                  <span
                    class="counter"
                    [countUp]="16"
                    [options]="{ suffix: '+' }"
                  ></span>
                </h1>
                <p>Years of Experience</p>
              </div>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="hadding9 about9-hadding">
              <h1 data-aos="fade-left" data-aos-duration="700">
                Partner with Our Trusted Consultants Today.
              </h1>
              <div class="space16"></div>
              <p data-aos="fade-left" data-aos-duration="900">
                At Tax Consulting Company, we are a trusted tax consulting firm
                with over 15 years of experience. Our mission is to provide
                exceptional tax services, personalized attention, and expert
                guidance to individuals and businesses. Our team of seasoned
                professionals
              </p>
              <div class="space20"></div>
              <p data-aos="fade-left" data-aos-duration="1100">
                Has in-depth knowledge of tax laws, Regulations, and industry
                best practices. We stay up-to-date with the latest changes in
                tax legislation to ensure we provide accurate and reliable
                advice.
              </p>
              <div class="space32"></div>
              <div class="" data-aos="fade-left" data-aos-duration="700">
                <a routerLink="/about" class="theme-btn12"
                  >More About Us<span
                    ><i class="fa-solid fa-arrow-right"></i></span
                ></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: ``,
})
export class AboutComponent {}
