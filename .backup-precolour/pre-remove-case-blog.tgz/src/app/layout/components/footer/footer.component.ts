import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

type footermenuType = {
  name: string;
  link?: string;
};

type socialIconType = {
  title: string;
  icon: string;
};

@Component({
  selector: 'app-footer',
  host: { 'app-footer': 'app-layout-footer' },
  imports: [RouterLink],
  templateUrl: './footer.component.html',
  styles: ``,
})
export class FooterComponent {
  currentYear: number = new Date().getFullYear();

  footermenu: footermenuType[] = [
    { name: 'Home', link: '/' },
    { name: 'Our Lateral Thinking', link: '/about' },
    { name: 'Service Catalog', link: '/service' },
    { name: 'Case Studies', link: '/case' },
    { name: 'Insights', link: '/blog' },
    { name: 'Contact', link: '/contact' },
  ];

  usefullinks: string[] = [
    '5D Assessment',
    'CTO-as-a-Service',
    'Enterprise Architecture-as-a-Service',
    'Tech Product LifeCycle-as-a-Service',
    'GCC GENESIS',
  ];

  socialIcons: socialIconType[] = [
    {
      title: 'Linked in',
      icon: 'fa-brands fa-facebook',
    },
    {
      title: 'Facebook',
      icon: 'fa-brands fa-linkedin-in',
    },
    {
      title: 'Instagram',
      icon: 'fa-brands fa-youtube',
    },
    {
      title: 'TikTok',
      icon: 'fa-brands fa-twitter',
    },
  ];
}
