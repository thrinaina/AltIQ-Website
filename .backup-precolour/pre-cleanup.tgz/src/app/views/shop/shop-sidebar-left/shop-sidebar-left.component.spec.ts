import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShopSidebarLeftComponent } from './shop-sidebar-left.component';

describe('ShopSidebarLeftComponent', () => {
  let component: ShopSidebarLeftComponent;
  let fixture: ComponentFixture<ShopSidebarLeftComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShopSidebarLeftComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShopSidebarLeftComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
