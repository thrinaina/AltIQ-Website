import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home8SectionsComponent } from './home-8-sections.component';

describe('Home8SectionsComponent', () => {
  let component: Home8SectionsComponent;
  let fixture: ComponentFixture<Home8SectionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Home8SectionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Home8SectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
