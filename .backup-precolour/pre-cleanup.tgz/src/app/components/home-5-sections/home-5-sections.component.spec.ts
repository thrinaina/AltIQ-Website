import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home5SectionsComponent } from './home-5-sections.component';

describe('Home5SectionsComponent', () => {
  let component: Home5SectionsComponent;
  let fixture: ComponentFixture<Home5SectionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Home5SectionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Home5SectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
