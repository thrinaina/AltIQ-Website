import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home6SectionsComponent } from './home-6-sections.component';

describe('Home6SectionsComponent', () => {
  let component: Home6SectionsComponent;
  let fixture: ComponentFixture<Home6SectionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Home6SectionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Home6SectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
