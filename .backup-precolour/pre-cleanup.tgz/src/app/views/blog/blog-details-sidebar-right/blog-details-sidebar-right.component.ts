import { Component } from '@angular/core';
import { BreadcrumbComponent } from "../../../components/breadcrumb.component";
import { BlogDetailsRightComponent } from '../components/blog-details-right.component';
import { BlogDetailsLeftComponent } from '../components/blog-details-left.component';
import { BodyClassDirective } from "../../../directive/body-class.directive";


@Component({
  selector: 'app-blog-details-sidebar-right',
  imports: [BreadcrumbComponent, BlogDetailsRightComponent, BlogDetailsLeftComponent, BodyClassDirective],
  templateUrl: './blog-details-sidebar-right.component.html',
  styles: ``
})
export class BlogDetailsSidebarRightComponent {

}
