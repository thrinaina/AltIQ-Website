import { Component } from '@angular/core';
import { BreadcrumbComponent } from '../../../components/breadcrumb.component';
import { RouterLink } from '@angular/router';
import { ThemePaginationComponent } from "../../../components/theme-pagination.component";
import { BodyClassDirective } from "../../../directive/body-class.directive";

type casestudyType = {
  image: string;
  title: string;
  des: string;
};

@Component({
  selector: 'app-case',
  imports: [BreadcrumbComponent, RouterLink, ThemePaginationComponent, BodyClassDirective],
  templateUrl: './case.component.html',
  styles: ``,
})
export class CaseComponent {


  casestudyData: casestudyType[] = [
    {
      image: 'assets/img/image/case1-img1.png',
      title: 'Financial Investment',
      des: 'Describe the HR challenges faced by the client and how your the solutions helped them achieve significant',
    },
    {
      image: 'assets/img/image/case1-img2.png',
      title: 'HR Consulting',
      des: 'Describe the HR challenges faced by the client and how your the solutions helped them achieve significant',
    },
    {
      image: 'assets/img/image/case1-img3.png',
      title: 'Cryptoocurrency Taxes',
      des: 'Describe the HR challenges faced by the client and how your the solutions helped them achieve significant',
    },
    {
      image: 'assets/img/image/case1-img4.png',
      title: 'Business Immigration',
      des: 'Describe the HR challenges faced by the client and how your the solutions helped them achieve significant',
    },
    {
      image: 'assets/img/image/case1-img5.png',
      title: 'Individual Taxation',
      des: 'Describe the HR challenges faced by the client and how your the solutions helped them achieve significant',
    },
    {
      image: 'assets/img/image/case1-img6.png',
      title: 'International Business',
      des: 'Describe the HR challenges faced by the client and how your the solutions helped them achieve significant',
    },
  ];
}
