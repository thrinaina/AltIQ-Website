import { Component } from '@angular/core';
import { HeroComponent } from "./components/hero.component";
import { AboutComponent } from "./components/about.component";
import { ServicesComponent } from "./components/services.component";
import { SolutionsComponent } from "./components/solutions.component";
import { CtaComponent } from './components/cta.component';
import { ProjectsComponent } from './components/projects.component';
import { TestimonialComponent } from "./components/testimonial.component";
import { BlogComponent } from "./components/blog.component";
import { ContactComponent } from "./components/contact.component";
import { FooterComponent } from "./components/footer.component";

@Component({
  selector: 'app-home-1-sections',
  imports: [HeroComponent, AboutComponent, ServicesComponent, SolutionsComponent, CtaComponent, ProjectsComponent, TestimonialComponent, BlogComponent, ContactComponent, FooterComponent],
  templateUrl: './home-1-sections.component.html',
  styles: ``
})

export class Home1SectionsComponent {

}
