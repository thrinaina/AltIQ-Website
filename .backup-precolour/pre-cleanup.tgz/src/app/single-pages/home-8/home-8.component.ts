import { Home8SectionsComponent } from './../../components/home-8-sections/home-8-sections.component';
import { Component } from '@angular/core';
import { NavbarComponent } from "./components/navbar.component";
import { BodyClassDirective } from "../../directive/body-class.directive";

@Component({
  selector: 'app-home-8',
  host: { 'app-home': 'app-single-home8' },
  imports: [
    NavbarComponent,
    BodyClassDirective,
    Home8SectionsComponent
],
  templateUrl: './home-8.component.html',
  styles: ``,
})
export class Home8Component {

}
