import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

type blogdataType = {
  image: string;
  tag: string;
  title: string;
  description: string;
  link: string;
  aosDuration: string;
};

@Component({
  selector: 'app-blog',
  host: { 'app-blog': 'app-single-blog6' },
  imports: [RouterLink],
  template: `
    <div class="blog6 sp3" id="blog">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 m-auto text-center">
            <div class="hadding6">
              <h1 data-aos="fade-up" data-aos-duration="900">
                Featured Blog Post
              </h1>
              <div class="space16"></div>
              <p data-aos="fade-up" data-aos-duration="1100">
                Discover the keys to boosting employee engagement and
                productivity in our latest blog post. We delve into strategies
                and insights that empower
              </p>
            </div>
          </div>
        </div>

        <div class="space30"></div>

        <div class="row">
          @for (post of blogPosts; track post) {
          <div class="col-lg-4 col-md-6">
            <div
              class="blog6-box"
              [attr.data-aos]="'fade-up'"
              [attr.data-aos-duration]="post.aosDuration"
            >
              <div class="blog6-box-img img100">
                <img [src]="post.image" alt="" />
              </div>
              <div class="hadding6 blog6-hadding">
                <a [routerLink]="[]" class="blog6-tag">{{ post.tag }}</a>
                <div class="space12"></div>
                <h3>
                  <a [routerLink]="post.link">{{ post.title }}</a>
                </h3>
                <div class="space16"></div>
                <p>{{ post.description }}</p>
                <div class="space16"></div>
                <a [routerLink]="post.link" class="blog6-learn">
                  Read More <span><i class="fa-solid fa-arrow-right"></i></span>
                </a>
                <p></p>
              </div>
            </div>
          </div>
          }
        </div>
      </div>
    </div>
  `,
  styles: ``,
})
export class BlogComponent {
  blogPosts:blogdataType[] = [
    {
      image: 'assets/img/image/blog6-img1.png',
      tag: '#Talent Management',
      title: 'Remote Work Best Practices: Keeping Teams Connected',
      description:
        'Learn how to ensure HR compliance and best mitigate risks in your organization while to be our maintaining a safe and compliant.',
      link: '/blog-details',
      aosDuration: '800',
    },
    {
      image: 'assets/img/image/blog6-img2.png',
      tag: '#Talent Management',
      title: 'Navigating HR Compliance: Tips for a Risk-Free Workplace',
      description:
        'Learn how to ensure HR compliance and best mitigate risks in your organization while to be our maintaining a safe and compliant.',
      link: '/blog-details',
      aosDuration: '1100',
    },
    {
      image: 'assets/img/image/blog6-img3.png',
      tag: '#Talent Management',
      title: 'Diversity and Inclusion in the Workplace: A Path to Success',
      description:
        'Learn how to ensure HR compliance and best mitigate risks in your organization while to be our maintaining a safe and compliant.',
      link: '/blog-details',
      aosDuration: '1200',
    },
  ];
}
