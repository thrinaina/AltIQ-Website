import { Component } from '@angular/core';

import { NavbarComponent } from "./components/navbar.component";
import { BodyClassDirective } from "../../directive/body-class.directive";
import { Home9SectionsComponent } from '../../components/home-9-sections/home-9-sections.component';

@Component({
  selector: 'app-home-9',
  host: { 'app-home': 'app-single-home9' },
  imports: [
    NavbarComponent,
    BodyClassDirective,
    Home9SectionsComponent
],
  templateUrl: './home-9.component.html',
  styles: ``,
})
export class Home9Component {

}
