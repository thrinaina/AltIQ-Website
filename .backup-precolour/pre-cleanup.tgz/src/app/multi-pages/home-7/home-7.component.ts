import { Component } from '@angular/core';
import { NavbarComponent } from "./components/navbar.component";
import { BodyClassDirective } from "../../directive/body-class.directive";
import { Home7SectionsComponent } from '../../components/home-7-sections/home-7-sections.component';

@Component({
  selector: 'app-home-7',
  imports: [NavbarComponent, Home7SectionsComponent ,BodyClassDirective],
  templateUrl: './home-7.component.html',
  styles: ``,
})
export class Home7Component {

}
