import { Component } from '@angular/core';
import { BreadcrumbComponent } from "../../components/breadcrumb.component";
import { About1Component } from "./components/about1.component";
import { CounterComponent } from "./components/counter.component";
import { ServicesComponent } from "./components/services.component";
import { BrandsComponent } from "./components/brands.component";
import { TeamComponent } from "./components/team.component";
import { BlogComponent } from "./components/blog.component";
import { BodyClassDirective } from "../../directive/body-class.directive";

@Component({
  selector: 'app-about',
  imports: [BreadcrumbComponent, About1Component, CounterComponent, ServicesComponent, BrandsComponent, TeamComponent, BlogComponent, BodyClassDirective],
  templateUrl: './about.component.html',
  styles: ``
})
export class AboutComponent {

}
