import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-about1',
  imports: [RouterLink],
  template: `
    <div class="about1 sp3" style="background-color: #EFF0F7;">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6">
            <div class="about1-image-all">
              <div class="about-1-img1 aniamtion-key-1">
                <img src="assets/img/shapes/about1-shape1.svg" alt="" />
              </div>
              <div class="about-1-img2 border5">
                <img src="assets/img/image/about1-img1.png" alt="" />
              </div>
              <div class="about-1-img3 border5">
                <img src="assets/img/image/about1-img2.png" alt="" />
              </div>
              <div class="about-1-img4">
                <img src="assets/img/image/about1-img3.png" alt="" />
              </div>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="page-hadding about1-hadding">
              <h1 class="titleGreathorned">
                Partner with Our Trusted Consultants Today.
              </h1>
              <div class="space24"></div>
              <p>
                At Advisor Consulting Company, we are a trusted business
                consulting firm dedicated to helping businesses thrive and reach
                their full potential.Our team of experienced consultants brings
                diverse industry
              </p>
              <div class="space20"></div>
              <p>
                knowledge and expertise in various business disciplines.We
                prioritize understanding your unique challenges and goals to
                deliver customized solutions tailored to your specific needs
              </p>
              <div class="space40"></div>
              <a [routerLink]="[]" class="comon-button">More About Us</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: ``,
})
export class About1Component {}
