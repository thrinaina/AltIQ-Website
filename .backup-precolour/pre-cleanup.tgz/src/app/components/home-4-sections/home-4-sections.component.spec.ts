import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home4SectionsComponent } from './home-4-sections.component';

describe('Home4SectionsComponent', () => {
  let component: Home4SectionsComponent;
  let fixture: ComponentFixture<Home4SectionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Home4SectionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Home4SectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
