import { Component } from '@angular/core';
import { NavbarComponent } from "./components/navbar.component";
import { BodyClassDirective } from "../../directive/body-class.directive";
import { Home10SectionsComponent } from '../../components/home-10-sections/home-10-sections.component';

@Component({
  selector: 'app-home-10',
  imports: [NavbarComponent, Home10SectionsComponent ,BodyClassDirective],
  templateUrl: './home-10.component.html',
  styles: ``,
})
export class Home10Component {

}
