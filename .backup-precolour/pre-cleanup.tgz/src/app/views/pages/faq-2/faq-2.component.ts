import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { NgbAccordionModule } from '@ng-bootstrap/ng-bootstrap';

type FaqItem = {
  question: string;
  answer: string;
  id: string;
};

@Component({
  selector: 'app-faq-2',
  imports: [NgbAccordionModule,CommonModule],
  templateUrl: './faq-2.component.html',
  styles: ``,
})
export class Faq2Component {
  faqItems: FaqItem[] = [
    {
      id: 'collapseOne',
      question: 'How to help you deal with any business ?',
      answer:
        'Coaching can be indicative of increased employee engagement; 65% of employees from companies with strong coaching cultures rated themselves as highly engaged. Coaching also has an impact on financial performance, with 60% of respondents from organizations with strong coaching cultures reporting their 2013 revenue to be above average, compared to their peer group.',
    },
    {
      id: 'collapseTwo',
      question: 'How to help you deal with any business ?',
      answer:
        'Coaching can be indicative of increased employee engagement; 65% of employees from companies with strong coaching cultures rated themselves as highly engaged. Coaching also has an impact on financial performance, with 60% of respondents from organizations with strong coaching cultures reporting their 2013 revenue to be above average, compared to their peer group.',
    },
    {
      id: 'collapseThere',
      question: 'How to help you deal with any business ?',
      answer:
        'Coaching can be indicative of increased employee engagement; 65% of employees from companies with strong coaching cultures rated themselves as highly engaged. Coaching also has an impact on financial performance, with 60% of respondents from organizations with strong coaching cultures reporting their 2013 revenue to be above average, compared to their peer group.',
    },
    {
      id: 'collapseFour',
      question: 'How to help you deal with any business ?',
      answer:
        'Coaching can be indicative of increased employee engagement; 65% of employees from companies with strong coaching cultures rated themselves as highly engaged. Coaching also has an impact on financial performance, with 60% of respondents from organizations with strong coaching cultures reporting their 2013 revenue to be above average, compared to their peer group.',
    },
    {
      id: 'collapseFive',
      question: 'How to help you deal with any business ?',
      answer:
        'Coaching can be indicative of increased employee engagement; 65% of employees from companies with strong coaching cultures rated themselves as highly engaged. Coaching also has an impact on financial performance, with 60% of respondents from organizations with strong coaching cultures reporting their 2013 revenue to be above average, compared to their peer group.',
    },
    {
      id: 'collapseSix',
      question: 'How long until I see results for my website?',
      answer:
        'Coaching can be indicative of increased employee engagement; 65% of employees from companies with strong coaching cultures rated themselves as highly engaged. Coaching also has an impact on financial performance, with 60% of respondents from organizations with strong coaching cultures reporting their 2013 revenue to be above average, compared to their peer group.',
    },
    {
      id: 'collapseSeven',
      question:
        'How many people from Directive will be managing my SEO project?',
      answer:
        'Coaching can be indicative of increased employee engagement; 65% of employees from companies with strong coaching cultures rated themselves as highly engaged. Coaching also has an impact on financial performance, with 60% of respondents from organizations with strong coaching cultures reporting their 2013 revenue to be above average, compared to their peer group.',
    },
  ];
}
