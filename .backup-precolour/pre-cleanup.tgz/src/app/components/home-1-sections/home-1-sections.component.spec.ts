import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home1SectionsComponent } from './home-1-sections.component';

describe('Home1SectionsComponent', () => {
  let component: Home1SectionsComponent;
  let fixture: ComponentFixture<Home1SectionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Home1SectionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Home1SectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
