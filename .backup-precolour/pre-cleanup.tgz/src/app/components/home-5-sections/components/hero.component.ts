import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-hero',
  host: { 'app-hero': 'app-single-hero5' },
  imports: [RouterLink],
  template: `
    <div class="main-hero main-hero5">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6 col-md-12 _relative">
            <div class="main-hadding5">
              <h1 data-aos="fade-right" data-aos-duration="800">
                Transform Your <span class="after2">Business</span> with Expert
                Consulting Services
              </h1>
              <div class="space24"></div>
              <p data-aos="fade-right" data-aos-duration="1000">
                Guiding Financial Success with Expertise and Precision. Drive
                Growth, Improve Efficiency and Make Informed DecisionsWe help
                business to perform with our customized solution helping them
                take business.
              </p>
              <div class="space40"></div>
              <div class="header2-buttons">
                <div
                  class="button2-all"
                  data-aos="fade-right"
                  data-aos-duration="1200"
                >
                  <a routerLink="/contact" class="theme-btn5"
                    >Schedule A Consultation
                    <span><i class="fa-solid fa-angle-right"></i></span
                  ></a>
                </div>
                <div class="button2-all2">
                  <a routerLink="/contact" class="theme-btn6"
                    >Contact Us
                    <span><i class="fa-solid fa-angle-right"></i></span
                  ></a>
                </div>
              </div>
            </div>

            <div class="hero5-commnt-area text-right">
              <div class="commnet-area-hadding">
                <div class="commnet-area-shape">
                  <img src="assets/img/shapes/hero5-shape.svg" alt="" />
                </div>
                <p>
                  Finance Consulting <br />
                  Expert Member
                </p>
              </div>
              <div class="commnet-area-img">
                <img src="assets/img/image/hero5-commnet.png" alt="" />
              </div>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="hero5-images">
              <div class="hero5-img1">
                <img src="assets/img/image/hero5-image1.png" alt="" />
              </div>
              <div class="hero5-img2">
                <img src="assets/img/image/hero5-image2.png" alt="" />
              </div>
              <div class="hero5-img3">
                <img src="assets/img/icons/hero5-icon.svg" alt="" />
                <p>Officially Certified</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: ``,
})
export class HeroComponent {}
