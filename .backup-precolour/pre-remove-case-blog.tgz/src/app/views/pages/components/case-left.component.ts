import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-case-left',
  imports: [RouterLink],
  template: `
    <div class="project-details-box">
      <div class="project-details-hadding">
        <h6>Project Details</h6>
      </div>

      <ul class="Category-list">
        <li>
          <a [routerLink]="[]"> Client Name: <span>Marico Inc. USA</span></a>
        </li>
        <li>
          <a [routerLink]="[]"
            >Category:<span>HR Strategy and Planning </span></a
          >
        </li>
        <li>
          <a [routerLink]="[]"> Timeline: <span>21 May - 07 June 2023</span></a>
        </li>
        <li>
          <a [routerLink]="[]"> Tags:<span>Agency, Marketing</span></a>
        </li>
      </ul>
    </div>
    <div class="space30"></div>
    <div class="need-help _relative">
      <div class="need-help-img img100">
        <img src="assets/img/image/service-details-sidebar-img.png" alt="" />
      </div>

      <div class="need-help-all">
        <p class="need-help-p">Need Any Help?</p>
        <div class="need-border"></div>
        <div class="coll-help">
          <div class="">
            <div class="coll-help-icon">
              <a [routerLink]="[]"><i class="fa-solid fa-phone"></i></a>
            </div>
          </div>
          <div class="coll-help-text">
            <a href="tel:123456789">123 456 789</a> <br />
            <a href="tel:123456789">123 456 789</a>
          </div>
        </div>
      </div>
    </div>
    <div class="space60"></div>
  `,
  styles: ``,
})
export class CaseLeftComponent {}
