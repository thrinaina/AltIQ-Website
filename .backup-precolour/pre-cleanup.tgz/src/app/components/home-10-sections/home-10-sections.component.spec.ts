import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Home10SectionsComponent } from './home-10-sections.component';

describe('Home10SectionsComponent', () => {
  let component: Home10SectionsComponent;
  let fixture: ComponentFixture<Home10SectionsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Home10SectionsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Home10SectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
