import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

type servicesType = {
  image: string;
  title: string;
  des: string;
  duration: number;
}

@Component({
  selector: 'app-services',
  host: { 'app-services': 'app-services4' },
  imports: [RouterLink],
  template: `
     <div class="service4 sp3" id="service" style="background-color: var(--aiq-surface-2);">
        <div class="container">
            <div class="row">
                <div class="col-lg-7 m-auto text-center">
                    <div class="hadding4">
                        <h1 data-aos="fade-up" data-aos-duration="700"> Services We Offered</h1>
                        <div class="space16"></div>
                        <p data-aos="fade-up" data-aos-duration="800">Our team of experienced consultants combines industry knowledge, cutting-edge technology, and innovative strategies to guide you towards a brighter and greener future. </p>
                    </div>
                </div>
            </div>
            <div class="space30"></div>
            <div class="row">

              @for(item of servicesData;track $index){
                <div class="col-lg-4 text-center">
                   <div class="" data-aos="fade-up" [attr.data-aos-duration]="item.duration">
                    <div class="service4-box">
                      <div class="service4-box-iocn">
                          <img [src]="item.image" alt="">
                      </div>
                      <div class="hadding4">
                          <h4><a routerLink="/service-details">{{item.title}}</a></h4>
                          <div class="space14"></div>
                          <p> {{item.des}} </p>
                          <div class="space24"></div>
                            <a class="read-more4" routerLink="/service-details">Read More <span><i class="fa-solid fa-arrow-right"></i></span></a>
                      </div>
                    </div>
                  </div>
                </div>
              }
            </div>
            <div class="space40"></div>
            <div class="row" data-aos="fade-up" data-aos-duration="700">
                <div class="col-lg-12 text-center">
                     <a routerLink="/service" class="button4-header4">More Services</a>
                </div>
            </div>
        </div>
    </div>
  `,
  styles: ``
})
export class ServicesComponent {

  servicesData: servicesType[] = [
    {
      image: 'assets/img/icons/service4-icon1.svg',
      title: 'Financial Planning and Analysis',
      des: 'Our experienced consultants help businesses develop comprehensive financial plans, perform financial forecasting',
      duration: 700,
    },
    {
      image: 'assets/img/icons/service4-icon1.svg',
      title: 'Financial Risk Management',
      des: 'Our experienced consultants help businesses develop comprehensive financial plans, perform financial forecasting',
      duration: 900,
    },
    {
      image: 'assets/img/icons/service4-icon3.svg',
      title: 'Capital Structure Optimization',
      des: 'Our experienced consultants help businesses develop comprehensive financial plans, perform financial forecasting',
      duration: 700,
    },
  ]
  
}
